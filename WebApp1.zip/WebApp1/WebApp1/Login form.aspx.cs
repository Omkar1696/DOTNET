﻿using System;

namespace WebApp1
{
    public partial class Login_form : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            if (txtUsername.Text == "Wipro" && txtPaswrd.Text == "12345")
            {
                Response.Redirect("Home.aspx");
            }
        }
    }
}