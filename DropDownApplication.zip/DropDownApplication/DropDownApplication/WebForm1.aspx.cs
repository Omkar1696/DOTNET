﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DropDownApplication
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
          if(!IsPostBack)
            {
                DropDownList1.Items.Clear();
                DropDownList1.Items.Add("--Select--");
                DropDownList2.Items.Clear();
                DropDownList2.Items.Add("--Select--");
                DropDownList3.Items.Clear();
                DropDownList3.Items.Add("--Select--");
                SqlConnection con = new SqlConnection("Server=.;Initial Catalog=DemoDB;User id=sa;Password=wipro@123");
                SqlCommand cmd = new SqlCommand("Select * from Country", con);
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                DropDownList1.DataSource = dr;
                DropDownList1.DataTextField = "CountryName";
                DropDownList1.DataValueField = "CountryID";
                DropDownList1.DataBind();
                con.Close();

            }
        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            DropDownList2.Items.Clear();
            DropDownList2.Items.Add("--Select--");
            DropDownList3.Items.Clear();
            DropDownList3.Items.Add("--Select--");
            SqlConnection con = new SqlConnection("Server=.;Initial Catalog=DemoDB;User id=sa;Password=wipro@123");
            SqlCommand cmd = new SqlCommand("Select * from State1 where CountryID=@Cid", con);
            cmd.Parameters.AddWithValue("@Cid",DropDownList1.SelectedValue);
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            DropDownList2.DataSource = dr;
            DropDownList2.DataTextField = "StateName";
            DropDownList2.DataValueField = "StateID";
            DropDownList2.DataBind();
            con.Close();


        }

        protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
        {
            DropDownList3.Items.Clear();
            DropDownList3.Items.Add("--Select--");
            SqlConnection con = new SqlConnection("Server=.;Initial Catalog=DemoDB;User id=sa;Password=wipro@123");
            SqlCommand cmd = new SqlCommand("Select * from City1 where StateID=@Sid", con);
            cmd.Parameters.AddWithValue("@Sid", DropDownList2.SelectedValue);
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            DropDownList3.DataSource = dr;
            DropDownList3.DataTextField = "CityName";
            DropDownList3.DataValueField = "CityID";
            DropDownList3.DataBind();
            con.Close();

        }

        protected void DropDownList3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}