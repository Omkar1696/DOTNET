﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Generic_collection__second
{
    class Program
    {
        static void Main(string[] args)
        {
            List<char> alpha = new List<char>();
            List<int> digit = new List<int>();

            Console.WriteLine("Enter a string");
            string input = Console.ReadLine();

            foreach(var chr in input)
            {
                if(char.IsDigit(chr))
                {
                    digit.Add(chr);
                }
                if(char.IsLetter(chr))
                {
                    alpha.Add(chr);
                }
            }
            //print(alpha);
            //print(digit);
            alpha.Sort();
            digit.Sort();

            Console.WriteLine("char list");
            foreach (var ele in alpha)
            {
                Console.WriteLine(ele);
            }

            Console.WriteLine("digit list");
            foreach (char ele in digit)
            {
                Console.WriteLine(ele);
            }


        }

        //static void print<T>(List<T> list)
        //{
        //    Console.WriteLine("{0} list",list.GetType());
        //    foreach (var ele in list)
        //    {
                
        //        Console.WriteLine(ele);
        //    }
        //}
    }
}
