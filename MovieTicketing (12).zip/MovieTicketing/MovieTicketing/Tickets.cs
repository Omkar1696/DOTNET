﻿using System;


namespace MovieTicketing
{
    public class Tickets
    {
        //TicketID as int
        //ShowID as int
        //CustomerName as string
        //ReferenceCode as string
        //BookingDate as Datetime
        //NumberofPersons as int
        //Amount as decimal
        //TicketStatus as string

        //TODO: Write code here.
        public int TicketID { get; set; }
        public int ShowID { get; set; }
        public string CustomerName { get; set; }
        public string ReferenceCode { get; set; }
        public DateTime BookingDate { get; set; }
        public int NumberofPersons { get; set; }
        public decimal Amount { get; set; }
        public string TicketStatus { get; set; }

    }
}
