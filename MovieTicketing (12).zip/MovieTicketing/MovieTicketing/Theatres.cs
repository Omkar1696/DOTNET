﻿using System;


namespace MovieTicketing
{
    public class Theatres
    {
        //TheatreID as int
        //TheatreName as string
        //SeatingCapacity as int

        //TODO: Write Code here

        public int TheatreID { get; set; }
        public string TheatreName { get; set; }
        public int SeatingCapacity { get; set; }


    }
}
