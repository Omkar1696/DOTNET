﻿using System;
using System.Data.SqlClient;

namespace MovieTicketing
{
    public class TicketingDataAccess
    {
        string ConnectionString = "Data Source=.;Initial Catalog=MovieTicketing;User ID=sa;Password=wipro@123";

        public bool AddMovie(Movies obj)
        {
            bool IsAdded = false;
            if (obj==null)
            {
                IsAdded = false;
            }

           else
            {
               
                //throw new NotImplementedException();
                SqlConnection con = new SqlConnection(ConnectionString);
                SqlCommand cmd = new SqlCommand("insert into Movies(MovieName,Director,PlaysPerDay,TicketPrice) values (@moviename,@director,@playsperday,@ticketprice)",con);
               
                cmd.Parameters.AddWithValue("@moviename", obj.MovieName);
                cmd.Parameters.AddWithValue("@director", obj.DirectorName);
                cmd.Parameters.AddWithValue("@playsperday", obj.PlaysPerDay);
                cmd.Parameters.AddWithValue("@ticketprice", obj.TicketPrice);
                cmd.Connection = con;
                con.Open();
               int i= cmd.ExecuteNonQuery();
               if(i>0)
                {
                    IsAdded = true;
                }
               else
                {
                    IsAdded = false;
                }

            }
            return IsAdded;

        }

        public bool AddTheatre(Theatres obj)
        {
            //throw new NotImplementedException();
            bool IsAdded = false;
            if (obj == null)
            {
                IsAdded = false;
            }

            else
            {

                //throw new NotImplementedException();
                SqlConnection con = new SqlConnection(ConnectionString);
                SqlCommand cmd = new SqlCommand("Insert into Theatres(TheatreName,SeatingCapacity) values (@theatrename,@seatingcapacity)", con);
                cmd.Parameters.AddWithValue("@theatrename", obj.TheatreName);
                cmd.Parameters.AddWithValue("@seatingcapacity", obj.SeatingCapacity);
                cmd.Connection = con;
                con.Open();
                int i = cmd.ExecuteNonQuery();
                if (i > 0)
                {
                    IsAdded = true;
                }
                else
                {
                    IsAdded = false;
                }

            }
            return IsAdded;


        }

        public bool AddShow(Shows obj)
        {
            //throw new NotImplementedException();

            bool IsAdded = false;
            if (obj == null)
            {
                IsAdded = false;
            }

            else
            {

                //throw new NotImplementedException();
                SqlConnection con = new SqlConnection(ConnectionString);
                SqlCommand cmd = new SqlCommand("Insert into Shows(TheatreID,MovieID,StartDate,EndDate,StartTime,EndTime) values (@theatreid,@movieid,@startDt,@endDt,@startTime,@endTime)", con);
                cmd.Parameters.AddWithValue("@theatreid", obj.TheatreID);
                cmd.Parameters.AddWithValue("@movieid", obj.MovieID);
                cmd.Parameters.AddWithValue("@startDt", obj.StartDate);
                cmd.Parameters.AddWithValue("@endDt", obj.EndDate);
                cmd.Parameters.AddWithValue("@startTime", obj.StartTime);
                cmd.Parameters.AddWithValue("@endTime", obj.EndTime);
                cmd.Connection = con;
                con.Open();
                int i = cmd.ExecuteNonQuery();
                if (i > 0)
                {
                    IsAdded = true;
                }
                else
                {
                    IsAdded = false;
                }

            }
            return IsAdded;

        }

        public string AddTicket(Tickets obj)
        {
            string refCode = null;
            if (obj != null)
            {
              
                string moviename ="";
                decimal ticketprice = 0;
                SqlConnection con = new SqlConnection(ConnectionString);
                SqlCommand cmd = new SqlCommand("select m.MovieName,m.TicketPrice from Movies m JOIN Shows s on m.MovieID=s.MovieID JOIN Tickets t on s.ShowID=t.ShowID where t.ShowID=@sid", con);
                cmd.Parameters.AddWithValue("@sid", obj.ShowID);
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                
                if (dr.HasRows)
                {
                    dr.Read();
                    moviename = dr["MovieName"].ToString();
                    ticketprice = decimal.Parse(dr["TicketPrice"].ToString());
                }
                con.Close();

                refCode += obj.CustomerName[0].ToString() + obj.CustomerName.ToString() + obj.NumberofPersons.ToString() + moviename[0] + moviename[1] + obj.BookingDate.Day.ToString() + obj.BookingDate.Month.ToString();
                Random rndm = new Random();
                rndm.Next(1, 1000);
                refCode += rndm;
                refCode += refCode.ToUpper();
            }
            return refCode;
        }


        public int DeleteMovie(int intMovieID)
        {
            int rowsdeleted = 0;
            SqlConnection con = new SqlConnection(ConnectionString);
            SqlCommand cmd = new SqlCommand("Select ShowID from Shows where MovieID=@mid", con);
            cmd.Parameters.AddWithValue("@mid", intMovieID);
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
           
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    int showid = int.Parse(dr["ShowID"].ToString());
                    SqlConnection con1 = new SqlConnection(ConnectionString);
                    SqlCommand cmd1 = new SqlCommand("Delete from Tickets where ShowId=@sid", con1);
                    cmd1.Parameters.AddWithValue("@sid", showid);
                    con1.Open();
                    int rows = cmd1.ExecuteNonQuery();
                    rowsdeleted += rows;
                    con1.Close();
                }
            }
            con.Close();
            //SqlConnection con2 = new SqlConnection(ConnectionString);
            SqlCommand cmd2 = new SqlCommand("Delete from Shows where MovieID = @mid",con);
            cmd2.Parameters.AddWithValue("@mid", intMovieID);
                  con.Open();
            int rows2 = cmd2.ExecuteNonQuery();
            con.Close();
            rowsdeleted += rows2;
            SqlCommand cmd3 = new SqlCommand("Delete from Movies where MovieId=@mid",con);
            cmd3.Parameters.AddWithValue("@mid",intMovieID);
            con.Open();
            int rows3 = cmd3.ExecuteNonQuery();
            con.Close();
            rowsdeleted += rows3;

            if(rowsdeleted==0)
            {
                return 0;
            }
                  else
            {
                return rowsdeleted;
            }



       }

    }

}
   

