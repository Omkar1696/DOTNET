﻿using System;


namespace MovieTicketing
{
    public class Movies
    {
        //MovieID as int 
        //MovieName as string 
        //Director as string 
        //PlaysPerDay as int 
        //TicketPrice as decimal

        //TODO: Write Code here    

        public int MovieID { get; set; }
        public string MovieName { get; set; }
        public string DirectorName { get; set; }
        public int PlaysPerDay { get; set; }
        public decimal TicketPrice { get; set; }

    }
}
