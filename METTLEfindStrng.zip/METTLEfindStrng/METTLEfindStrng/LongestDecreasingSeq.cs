﻿using System;
using System.Collections.Generic;

//Read only region start
public class UserMainCode
{
    //Assume following return types while writing the code for this question. 
    public class Result
    {
        public int output1;
        public int output2;
    }

    public Result decreasingSeq(int[] input1, int input2)
    {
        //Read only region end
        //Write code here
        int c = 1;
        int flag = 0;
        int longestseq = 0;
        for (int i = 1; i < input2; i++)
        {
            if (input1[i] < input1[i - 1])
            {
                c = c + 1;
            }
            else
            {
                if (c > longestseq && c != 1)
                {
                    longestseq = c;
                }
                if (c > 1)
                {
                    flag = flag + 1;
                }
                c = 1;
            }
        }
        if (c > longestseq && c != 1)
        {
            longestseq = c;
        }
        if (c > 1)
        {
            flag = flag + 1;
        }
        Result res = new Result();
        res.output1 = flag;
        res.output2 = longestseq;

        return res;

    }
}