﻿using System;
using System.Collections.Generic;

//Read only region start
public class UserMainCode
{
    public int findStringCode(string input1)
    {
        //Read only region end
        //Write code here
        string[] strArr = new string[10];
        int r = 0;
        string str = input1.ToUpper();
        string[] strarr = str.Split(' ');
        for (int i = 0; i < strarr.Length; i++)
        {
            char[] charr = strarr[i].ToCharArray();
            int sum = 0;
            for (int j = 0; j < charr.Length / 2; j++)
            {
                sum = sum + Math.Abs((GetValue(charr[j]) - GetValue(charr[charr.Length - 1 - j])));
            }
            if (charr.Length % 2 != 0)
            {
                sum = sum + GetValue(charr[(charr.Length / 2)]);
            }
            strArr[r++] = sum.ToString();

        }
        string St = "";
        for (int i = 0; i < r; i++)
        {
            St = St + strArr[i];
        }
        return int.Parse(St);

    }
    public int GetValue(char c)
    {
        return (int)c - 64;
    }

}

