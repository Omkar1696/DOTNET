﻿using System;
using System.Collections.Generic;

//Read only region start
public class UserMainCode
{
    public double FindAverage(int input1)
    {
        //Read only region end
        //Write code here
        int sum = 0;
        int count = 0;

        while (input1 > 0)
        {
            int rem = input1 % 10;
            count = count + 1;
            sum = sum + rem;
            input1 = input1 / 10;
        }
        double sum1 = sum;
        double count1 = count;
        double result = sum1 / count1;
        Console.WriteLine(result);
        return double.Parse(string.Format("{0:N2}", result));
    }
}