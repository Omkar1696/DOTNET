﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetManagement
{
    class Employee
    {
        /* EmployeeID as string
         EmployeeName as string 
         DateofJoining as DateTime
         Email as string
         Location as string
         Phone as long 
        */

        public string EmployeeId { get; set; }
        public string EmployeeName { get; set; }
        public DateTime DateofJoining { get; set; }
        public string Email { get; set; }
        public string Location { get; set; }
        public long Phone { get; set; }


    }
}
