﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetManagement
{
    public class AssetTracking
    {
        const string ConnectionString = "Data Source=.;Initial Catalog=AssetManagement;User ID=sa;Password=wipro@123";
        public bool AddAsset(Asset obj)
        {
            bool IsAdded = false;
            if (obj != null)
            {
                string serialno = "";
                Random rnd = new Random();
                int random = rnd.Next(1, 1000);
                serialno += obj.AssetType[0] + obj.AssetType[1] + random.ToString();
                obj.SerialNo = serialno;
                SqlConnection con = new SqlConnection(ConnectionString);
                SqlCommand cmd = new SqlCommand("Insert into Asset(AssetType,SerialNo,ProcurementDate,TaggingStatus) values (@at,@sn,@pd,@ts)", con);
                cmd.Parameters.AddWithValue("@at", obj.AssetType);
                cmd.Parameters.AddWithValue("@sn", obj.SerialNo);
                cmd.Parameters.AddWithValue("@pd", DateTime.Now);
                cmd.Parameters.AddWithValue("@ts", "FREE POOL");
                con.Open();
                int rows = cmd.ExecuteNonQuery();
                con.Close();
                if (rows == 1)
                {
                    IsAdded = true;
                }
                else
                {
                    IsAdded = false;
                }
            }
            else
            {
                IsAdded = false;
            }
            return IsAdded;
        }

        public bool ModifyAsset(Asset obj)
        {
            //throw new NotImplementedException();
            bool IsUpdated = false;
            if (obj != null)
            {
                SqlConnection con = new SqlConnection(ConnectionString);
                SqlCommand cmd = new SqlCommand("Update Asset set AssetName=@an,SerialNo=@sn,ProcurementDate=@pd where AssetID=@aid", con);
                cmd.Parameters.AddWithValue("@an", obj.AssetType);
                cmd.Parameters.AddWithValue("@sn", obj.SerialNo);
                cmd.Parameters.AddWithValue("@an", obj.ProcurementDate);
                con.Open();
                int rows1 = cmd.ExecuteNonQuery();
                con.Close();
                if (rows1 == 1)
                {
                    IsUpdated = true;

                }
                else
                {
                    IsUpdated = false;
                }
            }
            else
            {
                IsUpdated = false;
            }
            return IsUpdated;

        }

        public bool TagAsset(AssetTagging obj)
        {

            bool IsAdded = false;
            if (obj != null)
            {
                SqlConnection con = new SqlConnection(ConnectionString);
                SqlCommand cmd = new SqlCommand("Select TaggingStatus from Asset where AssetID=@aid", con);
                cmd.Parameters.AddWithValue("@aid", obj.AssetID);
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                { 
                    dr.Read();
                    string taggingstatus = dr["TaggingStatus"].ToString();
                    dr.Close();
                    if (taggingstatus == "Free Pool")
                        {
                            SqlConnection con1 = new SqlConnection(ConnectionString);
                            SqlCommand cmd1 = new SqlCommand("Insert into AssetTagging(AssetID,EmployeeID,TaggingDate) values(@aid,@eid,@td)", con1);
                            cmd1.Parameters.AddWithValue("@aid", obj.AssetID);
                            cmd1.Parameters.AddWithValue("@eid", obj.EmployeeID);
                            cmd1.Parameters.AddWithValue("@td", DateTime.Now);
                            con1.Open();
                            int rows = cmd1.ExecuteNonQuery();
                            con1.Close();
                            if (rows > 0)
                            {
                                SqlConnection con2 = new SqlConnection(ConnectionString);
                                SqlCommand cmd2 = new SqlCommand("Update Asset set TaggingStatus=@ts where AssetID=@aid", con2);
                                cmd2.Parameters.AddWithValue("@aid", obj.AssetID);
                                cmd2.Parameters.AddWithValue("@ts", "Tagged");
                                con2.Open();
                                int rows1 = cmd2.ExecuteNonQuery();
                                con2.Close();
                                IsAdded = true;

                            }

                        }  
                }
                con.Close();
            }
            return IsAdded;
        }

        public bool DeTagAsset(int intAssetId)
        {
            bool detagged = false;
            if (intAssetId == 0)
            {
                detagged = false;
            }
            else
            {
                SqlConnection con = new SqlConnection(ConnectionString);
                SqlCommand cmd = new SqlCommand("update AssetTagging set ReleaseDate=@rd where AssetID=@aid", con);
                cmd.Parameters.AddWithValue("@aid", intAssetId);
                cmd.Parameters.AddWithValue("@rd", DateTime.Now);
                con.Open();
                int rows=cmd.ExecuteNonQuery();
                if (rows>0)
                {
                    detagged = true;
                    
                 }
                 else
                 {
                     detagged= false;
                 }
                if(detagged==true)
                {
                   
                        SqlConnection con1 = new SqlConnection(ConnectionString);
                        SqlCommand cmd1 = new SqlCommand("Update Asset set TaggingStatus=@ts where AssetID=@aid", con1);
                        cmd1.Parameters.AddWithValue("@aid", intAssetId);
                        cmd1.Parameters.AddWithValue("@ts", "FREE POOL");
                        con1.Open();
                        int rows1 = cmd1.ExecuteNonQuery();
                        con1.Close();
                        if (rows1 == 1)
                        {
                            detagged = true;
                        }
                        else
                        {
                            detagged = false;
                        }
                    
               }
                
            }
            return detagged;
        }
    }
}
