﻿using System;
using System.Collections.Generic;

//Read only region start
public class UserMainCode
{
    public int getLen_LS_ODD(int[] input1, int input2)
    {
        //Read only region end
        //Write code here
        int longest = 0;
        int count = 1;
        for (int i = 1; i < input2; i++)
        {
            if (input1[i] % 2 != 0)
            {
                count++;
            }
            else
            {
                if (count > longest && count != 1)
                {
                    longest = count;
                }

                count = 1;
            }

        }

        if (longest < count && count != 1)
        {
            longest = count;
        }

        return longest - 1;

    }
}