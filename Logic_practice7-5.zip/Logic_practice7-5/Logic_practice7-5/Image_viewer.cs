﻿using System;
using System.Collections.Generic;

//Read only region start
public class UserMainCode
{
    public int findNumberOfImages(int[] input1, char[] input2)
    {
        //Read only region end
        //Write code here
        //throw new NotImplementedException("Method  findNumberOfImages(int[] input1,char[] input2) not Implemented.");
        int m = input1[0];
        int n = input1[1];
        int o = input1[2];
        int p = input1[3];
       
        int time = 0;
        int count = 0;
        if (input2[0] == 'h' && o > p)
        {
            count = 0;
        }
        else
        {
            for (int i = 0; i < m; i++)
            {
                if (i == 0)
                {
                    if (input2[i] == 'v')
                    {
                        time = time + 1;
                    }
                    if (input2[i] == 'h')
                    {
                        time = time + o + 1;
                    }
                }
                else
                {
                    if (input2[i] == 'v')
                    {
                        time = time + n + 1;
                    }
                    if (input2[i] == 'h')
                    {
                        time = time + o + n + 1;
                    }
                }

                if (time <= p)
                {
                    count++;
                }
                else
                {
                    break;
                }
            }

        }
        return count;
    }
}
