﻿using System;
using System.Collections.Generic;

//Read only region start
public class UserMainCode
{
    public int FindMinDays(int input1, string input2)
    {
        //Read only region end
        //Write code here
        //throw new NotImplementedException("Method  FindMinDays(int input1,string input2) not Implemented.");
        string[] str = input2.Split(' ');
        int[] intarr = new int[str.Length];
        int days = 0;
        int m = 0;
        for (int j = 0; j < str.Length; j++)
        {
            intarr[j] = int.Parse(str[j]);
        }
        Array.Sort(intarr);
        Array.Reverse(intarr);
        for (int i = 0; i < intarr.Length; i++)
        {
            m = m + intarr[i];
            if (m < input1)
            {
                days = days + 1;
            }
            else if (m >= input1)
            {
                days = days + 1;
                break;
            }


        }

        if (input1 > m)
        {
            return -1;
        }
        if (input1 == 0)
        {
            return 0;
        }
        else
        {
            return days;
        }
    }
}