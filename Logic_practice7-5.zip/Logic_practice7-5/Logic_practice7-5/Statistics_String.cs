﻿using System;
using System.Collections.Generic;

//Read only region start
public class UserMainCode
{
    public string StringStatistics(string input1)
    {
        //Read only region end
        //Write code here
        //throw new NotImplementedException("Method  StringStatistics(string input1) not Implemented.");
        int count = 0;
        int temp = 0;
        int sum = 0;
        string res = "";
        string str1 = "";

        for (int i = 0; i < input1.Length; i++)
        {
            if (char.IsDigit(input1[i]))
            {
                sum = sum + int.Parse(input1[i].ToString());
                count = count + 1;
            }
            else if (char.IsLetter(input1[i]))
            {
                str1 = str1 + input1[i];
                temp = temp + 1;
            }

        }
        res = res + temp.ToString() + str1 + sum.ToString();
        if (sum == 0 || count == 0 || temp == 0)
        {
            return "ZERO";
        }
        else
        {
            return res;
        }
    }
}