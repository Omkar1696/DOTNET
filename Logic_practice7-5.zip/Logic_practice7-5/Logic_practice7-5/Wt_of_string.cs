﻿using System;
using System.Collections.Generic;

//Read only region start
public class UserMainCode
{
    public int weightOfString(string input1, int input2)
    {
        //Read only region end
        //Write code here
        //throw new NotImplementedException("Method  weightOfString(string input1,int input2) not Implemented.");
        int weight = 0;
        input1 = input1.ToUpper();


        int len = input1.Length;
        for (int i = 0; i < len; i++)
        {

            if (input2 == 0)
            {
                if (input1[i] > 'A' && input1[i] <= 'Z' && input1[i] != 'A' && input1[i] != 'E' && input1[i] != 'I' && input1[i] != 'O' && input1[i] != 'U')
                {
                    weight = weight + (int)input1[i] - 64;
                }

            }
            if (input2 == 1)
            {
                if (input1[i] >= 'A' && input1[i] <= 'Z')
                {
                    weight = weight + (int)input1[i] - 64;
                }

            }
        }
        return weight;

    }
}