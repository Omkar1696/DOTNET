﻿using System;
using System.Collections.Generic;

//Read only region start
public class UserMainCode
{
    public int AddSub(int input1, int input2)
    {
        //Read only region end
        //Write code here
        int[] intarr = new int[input1];
        int sum = input1;
        int first = input1;
        int sum1 = 0;
        int res = 0;
        for (int i = 0; i < input1; i++)
        {
            intarr[i] = first;
            first = first - 1;
        }
        if (input2 == 1)
        {
            for (int j = 2; j < input1; j = j + 2)
            {
                sum = sum + intarr[j];
            }
            for (int k = 1; k < input1; k = k + 2)
            {
                sum1 = sum1 - intarr[k];
            }
            res = sum + sum1;
        }

        if (input2 == 2)
        {
            for (int l = 2; l < input1; l = l + 2)
            {
                sum = sum - intarr[l];
            }
            for (int m = 1; m < input1; m = m + 2)
            {
                sum1 = sum1 + intarr[m];
            }
            res = sum + sum1;
        }
        return res;
    }
}