﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CollectionEmp
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee Emp1 = new Employee("John",11,1000);
            Employee Emp2 = new Employee("Jason",12,10000);
            Employee Emp3 = new Employee("Jonathan",13,100000);
            Employee Emp4 = new Employee("Jose",14,1000000);
            EmployeeDAL empdata = new EmployeeDAL();

            empdata.AddEmployee(Emp1);
            empdata.AddEmployee(Emp2);
            empdata.AddEmployee(Emp3);
            empdata.AddEmployee(Emp4);

            empdata.DeleteEmployee(6);
            empdata.DeleteEmployee(12);


            Console.WriteLine(empdata.SearchEmployee(14));

            Employee[] Arr = empdata.GetAllEmployeeListAll() as Employee[];
            foreach (var inst in Arr)
            {
                Console.WriteLine(inst.EmployeeName + "\t" + inst.EmployeeID + "\t" + inst.Salary);

            }
        }
    }
}
