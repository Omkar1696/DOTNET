﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CollectionEmp

{
    class EmployeeDAL
    {
        ArrayList obj = new ArrayList();

        public bool AddEmployee(Employee e)
        {
            if(obj.Add(e)<0)
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        public bool DeleteEmployee(int id)
        {
            bool Isfound = false;
            for(int i=0;i<obj.Count;i++)
            {
                Employee Empl = obj[i] as Employee;
                if(Empl.EmployeeID ==id)
                {
                    obj.Remove(Empl);
                    Isfound = true;
                    break;
                }
            }
            return Isfound;
        }
        public string SearchEmployee(int id)
        {
            if (obj.Count > id)
            {
                Employee Temp = obj[id] as Employee;
                return (Temp.EmployeeName);
            }
            else
            {
                return "Employee id not found";
            }
        }

        public Employee[] GetAllEmployeeListAll()
        {
            return obj.ToArray(typeof(Employee)) as Employee[];
        }
    }
}


