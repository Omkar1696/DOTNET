﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sum3nums
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] numbers = new int[3];
            int sum=0;
            for (int i = 0; i < 3; i++)
            {
             numbers[i] = Convert.ToInt32(Console.ReadLine());
            }
            for (int i = 0; i < 3; i++)
            {
                sum = sum + numbers[i];
            }
            Console.WriteLine("addition is {0}",sum);
        }
    }
}
