﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employeeclass
{
    class Employee
    {
        private string EmployeeName;
        private double BasicSalary;
        private double HRA;
        private double DA;
        private double Tax;
        private double GrossSalary;
        private double NetSalary;

        public Employee(string EmployeeName,double BasicSalary)
        {
            this.EmployeeName = EmployeeName;
            this.BasicSalary = BasicSalary;
        }
        public void CalculateNetPay()
        {
            HRA = BasicSalary * 0.15;
            DA = 0.10 * BasicSalary;
            GrossSalary = BasicSalary + HRA + DA;
            Tax = 0.08 * GrossSalary;
            NetSalary = GrossSalary - Tax;
        }
        public void DisplayStructure()
        {
            Console.WriteLine("Employee Name={0}",EmployeeName);
            Console.WriteLine("NetSalary Salary={0}",NetSalary);
            Console.WriteLine("Basic Salary={0}",BasicSalary);
            Console.WriteLine("Gross Salary={0}",GrossSalary);
            Console.WriteLine("HRA={0}",HRA);
            Console.WriteLine("DA={0}",DA);
            Console.WriteLine("Tax={0}",Tax);
        }
    }
}
