﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employeeclass
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee Emplyee = new Employee("Ajinkya I.", 1000000);
            Emplyee.CalculateNetPay();
            Emplyee.DisplayStructure();
            Console.ReadKey();
        }
    }
}
