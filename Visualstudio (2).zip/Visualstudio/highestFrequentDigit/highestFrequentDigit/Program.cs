﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace highestFrequentDigit
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] Arr = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
            do
            {
                int digit = input1 % 10;
                Arr[digit] = Arr[digit] + 1;
                input1 = input1 / 10;
            } while (input1 > 0);
            do
            {
                int digit = input2 % 10;
                Arr[digit] = Arr[digit] + 1;
                input2 = input2 / 10;
            }
            while (input2 > 0);
            do
            {
                int digit = input3 % 10;
                Arr[digit] = Arr[digit] + 1;
                input3 = input3 / 10;
            }
            while (input3 > 0);
            do
            {
                int digit = input4 % 10;
                Arr[digit] = Arr[digit] + 1;
                input4 = input4 / 10;
            }
            while (input4 > 0);

            for (int i = 16; i >= 1; i--)
            {
                for (int j = 9; j >= 0; j--)
                {
                    if (Arr[j] == i)
                    {
                        return j;
                    }
                }
            }
            return 0;
        }
    }
}
