﻿using System;
namespace ArofSqr
{
    class Program
    {
        static void Main(string[] args)
        {
            int side;
            Console.Write("Enter the side :");
            side = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Area of square is " + side * side);
            Console.ReadKey();
        }
    }
}
