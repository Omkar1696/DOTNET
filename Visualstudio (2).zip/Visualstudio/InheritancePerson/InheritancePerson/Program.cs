﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritancePerson
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee Emp = new Employee(100000,"John", "Richards", "johnrich@dotnet.com", new DateTime(1985, 11, 10));
            Emp.NetPay();
        }
    }
}
