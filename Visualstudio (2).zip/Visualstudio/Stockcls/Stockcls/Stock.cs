﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Stockcls
{
    class Stock
    {
        private string StockName;
        private string StockSymbol;
        private double PreviousClosingPrice;
        private double CurrentClosingPrice;


        public Stock(string StockNm,string StockSymb, double PrevClosPr,double CurntClosPr)
        {
            StockName = StockNm;
            StockSymbol = StockSymb;
            PreviousClosingPrice = PrevClosPr;
            CurrentClosingPrice = CurntClosPr;
        }
        public double GetChangePercentage()
        {
           
            Console.WriteLine("Stock's name= {0}", StockName);
            Console.WriteLine("Stock's Symbol= {0}", StockSymbol);
            Console.WriteLine("Previous Closing Price= {0}", PreviousClosingPrice);
            Console.WriteLine("Current Closing Price= {0}", CurrentClosingPrice);
            return Math.Abs(((PreviousClosingPrice - CurrentClosingPrice) / PreviousClosingPrice) * 100);
                

    }
}
}
