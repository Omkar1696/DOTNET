﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MiniProjectSorting
{
    class Program
    {
        static void Main(string[] args)
        {
            int a;
            Console.WriteLine("Enter the number of words");
            a = Convert.ToInt32(Console.ReadLine());

            string[,] arr1 = new string[a,3];

            for(int i=0;i<a;i++)
            {
                arr1[i,0] = Console.ReadLine();
                arr1[i,1] = Console.ReadLine();
                arr1[i,2] = Console.ReadLine();

            }

        }
    }
}
