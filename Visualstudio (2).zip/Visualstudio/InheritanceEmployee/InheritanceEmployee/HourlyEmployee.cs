﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceEmployee
{
    class HourlyEmployee : person,IPayable
    {
        double HoursWorked;
        double PayPerHour;

        public HourlyEmployee(double hoursworked, double payperhour, string FName, string LName, string Mail, DateTime DOB) : base (FName, LName, Mail, DOB)
        {
            HoursWorked = hoursworked;
            PayPerHour = payperhour;
        }
        public void Display()
        {
            Console.WriteLine("Hours Worked {0}",HoursWorked);
            Console.WriteLine("Pay per hour is {0}",PayPerHour);
        }
        public void CalculatePay()
        {
            double Payment = HoursWorked * PayPerHour;
            Console.WriteLine("Payment is {0}",Payment);
        }
    }
}
