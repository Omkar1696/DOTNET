﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceEmployee
{
    class PermanentEmployee : Employee,IPayable
    {
        
        private double BasicSalary;
        private double HRA;
        private double DA;
        private double Tax;
        private double GrossSalary;
        private double NetSalary;

        public PermanentEmployee(double Salary, string FName, string LName, string Mail, DateTime DOB) : base(Salary, FName, LName, Mail, DOB)
        {
            
       
            HRA = Salary * 0.15;
            DA = 0.10 * Salary;
            GrossSalary = Salary + HRA + DA;
            Tax = 0.08 * GrossSalary;
            NetSalary = GrossSalary - Tax;
        }
        public void DisplayStructure()
        {
            Console.WriteLine("NetSalary Salary={0}", NetSalary);
            Console.WriteLine("Gross Salary={0}", GrossSalary);
            Console.WriteLine("HRA={0}", HRA);
            Console.WriteLine("DA={0}", DA);
            Console.WriteLine("Tax={0}", Tax);
        }
        public void CalculatePay()
        {
            Console.WriteLine("Salary of Permanent Employee");
        }
    }
}
