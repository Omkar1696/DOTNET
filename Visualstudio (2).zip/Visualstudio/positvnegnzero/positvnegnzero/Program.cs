﻿using System;


namespace positvnegnzero
{
    class Program
    {
        static void Main(string[] args)
        {
            //int i;
            int positive = 0;
            int negative = 0;
            int[] number = new int[5];
            for (int i = 0; i < 5; i++)
            {
                number[i] = Convert.ToInt32(Console.ReadLine());
            }
            for (int i = 0; i < 5; i++)
            {
                if (number[i] < 0)
                {
                    negative = negative + 1;
                    
                }
                else
                {
                    positive = positive + 1;
                    
                }
            }
            Console.WriteLine("negative {0}",negative);
            Console.WriteLine("positive {0}",positive);
         }

      }

 }

