﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IntetfaceDemo
{
    interface FirstInterface
    {
        void Display1();
    }

    interface SecondInterface
    {
        void Display2();
    }
    class Demo : FirstInterface,SecondInterface
    {
        public void Display1()
        {
            Console.WriteLine("Display from First Interface method");
        }

        public void Display2()
        {
            Console.WriteLine("Display from Second Interface method");
        }
    }
}
