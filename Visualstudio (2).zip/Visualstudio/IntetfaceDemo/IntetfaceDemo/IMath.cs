﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IntetfaceDemo
{
    interface IMath
    {        
        void Add(int a, int b);
        void Subtract(int a, int b);
    }
}
