﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PropertiesDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee obj;
            obj = new Employee();
           
            Console.WriteLine("Property function...");
            obj.EmployeeName = "Scott";
            Console.WriteLine(obj.EmployeeID);
            Console.WriteLine(obj.EmployeeName);            
            Console.WriteLine("Modified:"+obj.EmployeeID);


            Employee objNew = new Employee() {
                EmployeeName="Smith"
            };

            Console.WriteLine(objNew.EmployeeID);
            Console.WriteLine(objNew.EmployeeName);
        }
    }
}
