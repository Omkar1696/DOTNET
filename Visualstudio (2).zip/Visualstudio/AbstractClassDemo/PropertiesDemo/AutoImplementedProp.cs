﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PropertiesDemo
{
    namespace AutoimplemetedProperties
    {
        class Employee
        {
            public int EmployeeID { get; }
            public string EmployeeName { get; set; }

            public Employee()
            {
                EmployeeID = new Random().Next();
            }
            static void Main(string[] args)
            {
                Employee obj = new Employee() {
                    EmployeeName="Scott"
                };

                Console.WriteLine("ID:"+obj.EmployeeID);
                Console.WriteLine("Name:"+obj.EmployeeName);
                
            }
        }
    }
}
