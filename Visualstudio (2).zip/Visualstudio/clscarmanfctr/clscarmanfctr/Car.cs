﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace clscarmanfctr
{
    class Car
    {
        private string carmake;
        private string model;
        private int mfgyear;
        private int price;

        public Car(string manufactrer,string modelname,int mfgyear,int pricevalue)
        {
            carmake = manufactrer;
            model = modelname;
            this.mfgyear = mfgyear;
            price = pricevalue;
        }

        public void DisplayCar()
        {
            Console.WriteLine("carmake= {0}",carmake);
            Console.WriteLine("model= {0}",model);
            Console.WriteLine("mfgyear= {0}",mfgyear);
            Console.WriteLine("price= {0}",price);
        }
    }
}
