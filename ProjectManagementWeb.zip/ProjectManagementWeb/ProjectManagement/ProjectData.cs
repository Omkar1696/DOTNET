﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectManagement
{
    public class ProjectData
    {
        const string ConnectionString = "Server=.;Initial Catalog=ProjectManagement;User ID=sa;Password=wipro@123";
        public string AddProject(Project obj)
        {
            throw new NotImplementedException();
        }

        public Project GetProjctByID(string strProjectID)
        {
            throw new NotImplementedException();
        }

        public int UpdateProject(Project obj)
        {
            throw new NotImplementedException();
        }

        public int DeleteProject(string strProjectID)
        {
            throw new NotImplementedException();
        }
    }
}
