create table Country(CountryID int primary key,CountryName varchar(20));
Create table State1
(
  StateID int primary key,
  StateName varchar(20),
  CountryID int foreign key references Country(CountryID)
);

create table City1
(
  CityID int primary key,
  CityName varchar(20),
  StateID int foreign key references State1(StateID)
);
insert into Country values(101,'India');
insert into Country values(102,'USA');

insert into State1 values(201,'Maharashtra',101);
insert into State1 values(202,'Telangana',101);
insert into State1 values(203,'California',102);
insert into State1 values(204,'Texas',102);


insert into City1 values(301,'Mumbai',201);
insert into City1 values(302,'Pune',201);
insert into City1 values(303,'Hyderabad',202);
insert into City1 values(304,'Secundarabad',202);
insert into City1 values(305,'Los Angeles',203);
insert into City1 values(306,'San Fancisco',203);
insert into City1 values(307,'Houston',204);
insert into City1 values(308,'Dallas',204);

Select * from Country;
Select * from State1;
Select * from City1;