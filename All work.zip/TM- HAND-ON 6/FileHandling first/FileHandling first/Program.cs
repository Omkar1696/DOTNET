﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileHandling_first
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the file path");
            string input = Console.ReadLine();

            if (File.Exists(input))
            {
                //string[] output = File.ReadAllLines(input);
                //Console.WriteLine(output);
                string str = File.ReadAllText(input);

                Console.WriteLine(str);


            }
            else
            {
                Console.WriteLine("File doesn't Exist ");
            }
        }
    }
}
