﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileHandling_second
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the file path");
            string input = Console.ReadLine();

            if (File.Exists(input))
            {
                //string[] output = File.ReadAllLines(input);
                //Console.WriteLine(output);
                //initial Display
                string str = File.ReadAllText(input);
                Console.WriteLine("Before editing");
                Console.WriteLine(str);

                //taking the inputs
                Console.WriteLine(  "Enter a line to be added in the above file");
                string towrite = Console.ReadLine();
                var writer =File.AppendText(input);
                writer.WriteLine("\n" +towrite);
                writer.Close();

                //final display
                Console.WriteLine("After editing");
                str = File.ReadAllText(input);
                Console.WriteLine(str);



            }
            else
            {
                Console.WriteLine("File doesn't Exist ");
            }
        }
    }
}
