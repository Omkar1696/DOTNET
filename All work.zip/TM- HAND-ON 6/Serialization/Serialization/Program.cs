﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;

namespace Serialization
{
    class Program
    {
        static void Main(string[] args)
        {
            // Write a program to Write 
            // 1) string object 
            // 2) a Double object and
            // 3) A Long object to a file and read it back from the file
            string Stringobject = "some words";
            double Dvalue = 3.14;
            long Lvalue = 2134567;


            BinaryFormatter objFormatter = new BinaryFormatter();
            FileStream objStream = new FileStream("project_variable.txt", FileMode.Create);
            objFormatter.Serialize(objStream, Stringobject);
            objFormatter.Serialize(objStream, Dvalue);
            objFormatter.Serialize(objStream, Lvalue);

            objStream.Close();
            Console.WriteLine("Object serialized...");
            objStream = new FileStream("project_variable.txt", FileMode.Open);
            // empData = objFormatter.Deserialize(objStream);



          
            string stringobject = (string)objFormatter.Deserialize(objStream);
            double dvalue =(double) objFormatter.Deserialize(objStream);
            long lvalue = (long)objFormatter.Deserialize(objStream);

            Console.WriteLine(stringobject);
            Console.WriteLine(dvalue);
            Console.WriteLine(lvalue);
        }
    }
}
