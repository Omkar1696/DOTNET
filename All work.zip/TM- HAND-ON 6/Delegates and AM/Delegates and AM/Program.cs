﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Delegates_and_AM
{
    class Program
    {
       
            //Create a delegate which takes an integer array as the parameter.
            //Create 3 methods Print(), Reverse() and Sort() which matches the signature of the delegate.
            //Point the delegate to those respective methods and instanciate the delegate to call the methods.

        public delegate void GeneralOPs(params int[] arr);

        static public void Reversed(params int[] arr)
        {
            Array.Reverse(arr);
            Console.WriteLine("Reversed array");
            foreach (var inst in arr )
            {
                Console.WriteLine(inst);
            }
        }

        static public void print(params int[] arr)
        {
            
            Console.WriteLine("Print array");
            foreach (var inst in arr)
            {
                Console.WriteLine(inst);
            }
        }
        static public void sorts(params int[] arr)
        {
            Array.Sort(arr);
            Console.WriteLine("Sorted array");
            foreach (var inst in arr)
            {
                Console.WriteLine(inst);
            }
        }
        static void Main(string[] args)
        {
            // Creating the Delegate instance.
            GeneralOPs obj = new GeneralOPs(print);

            // Invoking the delegate.
            //obj(10, 20,40,60,20,70);

            // Adding more methods.

            obj += Reversed;
            obj += sorts;
            Console.WriteLine("Output of all ther delegates");
            obj(10, 20, 40, 60, 20, 70);
          
           

          

            obj += delegate (int[] arr) {
                int mul = 1;
                foreach (var inst in arr)
                {
                    mul = mul * inst;
                }
                Console.WriteLine("multiplication of all the element of aray " + mul);
            }; // Anonymous method

            obj(100, 200,300,400);

        }
    }
}




string in1 = Convert.ToString(input1);
string in2 = Convert.ToString(input2);
string in3 = Convert.ToString(input3);
string in4 = Convert.ToString(input4);
string in5 = Convert.ToString(input5);

char[] arr1 = in1.ToCharArray();
char[] arr2 = in2.ToCharArray();
char[] arr3 = in3.ToCharArray();
char[] arr4 = in4.ToCharArray();
char[] arr5 = in5.ToCharArray();
Array.Sort(arr1);
		Array.Sort(arr2);
		Array.Sort(arr3);
		Array.Sort(arr4);
		Array.Sort(arr5);
		string tenone1 = arr1[0].ToString() + arr1[1].ToString();
string tenone2 = arr2[0].ToString() + arr2[1].ToString();
string tenone3 = arr3[0].ToString() + arr3[1].ToString();
string tenone4 = arr4[0].ToString() + arr4[1].ToString();
string tenone5 = arr5[0].ToString() + arr5[1].ToString();
int num1 = int.Parse(tenone1);
int num2 = int.Parse(tenone2);
int num3 = int.Parse(tenone3);
int num4 = int.Parse(tenone4);
int num5 = int.Parse(tenone5);
		
		return num1+num2+num3+num4+num5;





int[] arr = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
Console.WriteLine(input1);
		int num = input1;
		while(num != 0)
		{
			int digit = num % 10;
arr[digit] = arr[digit] +1;
			num = num/10;
		}
		
		num = input2;
		while(num != 0)
		{
			int digit = num % 10;
arr[digit] = arr[digit] +1;
			num = num/10;
		}
		num = input3;
		while(num != 0)
		{
			int digit = num % 10;
arr[digit] = arr[digit] +1;
			num = num/10;
		}
		num = input4;
		while(num != 0)
		{
			int digit = num % 10;
arr[digit] = arr[digit] +1;
			num = num/10;
		}
		for(int j = 1; j<=16;j++){
		for(int i = 0; i<10;i++){
		{
			if(arr[i] == j)
				return i;
	       }
        }
		}
		
		return 1;
}
}






int long_sequence = 0;
int number_of_sequence = 0;
int count = 0;
		//foreach(var single in input1){
		for(int i = 1; i<input1.Length;i++)
		{
			if(input1[i - 1] >input1[i])
			{
				count +=1;	
			}
			else{
				if (count >1)
				{
					number_of_sequence +=1;
				    if (count >long_sequence)
					{
						long_sequence = count;
					}
				}
			}
		
		}
	    Result res = new Result();
res.output1 = number_of_sequence;
	       res.output2 = long_sequence;
	return res;
    }
}




//new program 3


 int number_of_sequence = 0;
int long_sequence = 0;
int count = 1;

            //foreach(var single in input1){
            for (int i = 1; i<input1.Length; i++)
            {
                if (input1[i - 1] > input1[i])
                {
                    count += 1;
                }
                else
                {
                    if (count > 1)
                    {
                        number_of_sequence += 1;

                        if (count > long_sequence)
                        {
                            long_sequence = count;
                        }
                        count = 1;
                    }
                }

            }

            //Console.WriteLine(number_of_sequence);
            //Console.WriteLine(long_sequence);
            Result res = new Result();
res.output1 = number_of_sequence;
			res.output2 = long_sequence;
			return res;
        }
    }