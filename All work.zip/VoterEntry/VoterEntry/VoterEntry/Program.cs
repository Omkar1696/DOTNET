﻿using System;
using VoterEntry.Utility;

namespace VoterEntry
{
    class Program
    {
        static void Main(string[] args)
            
        {
            try
            {
                DateTime DateofBirt = new DateTime(1996, 04, 09);
                Console.WriteLine(DateTime.Now.Subtract(DateofBirt).Days / 365);
                Voter per = new Voter("john", "smith", "fathername", "M", "london", "baker street", new DateTime(1989, 06,21));
                VoterUtility utl = new VoterUtility();
                Console.WriteLine(utl.GenerateVoterID("john", "smith", new DateTime(1989, 06, 21)));
                Console.WriteLine(per.VoterID);
                

                VoterManagement vm = new VoterManagement();
                Voter son = new Voter();
                Console.WriteLine("count =" +vm.VoterList.Count);
                vm.AddVoter(son);
                vm.ModifyVoter(son);
                Console.WriteLine("count  after=" + vm.VoterList.Count);
                Console.WriteLine(utl.GenerateVoterID("john", "kevin", new DateTime(1989, 06, 21)));
                Console.WriteLine(per.VoterID);
                
            }
            catch(Exception ex)
            {
                Console.WriteLine( ex.Message);
                Console.WriteLine(ex.StackTrace);
            }
        }
    }
}


//    string strFirstName = "john";
//    string strLastName = "smith";


//    DateTime dtDateofBirth = new DateTime(1999, 21, 06);
//    DayOfWeek third = dtDateofBirth.DayOfWeek;
//    string thr = third.ToString();
//    char first = strFirstName[0];
//    char second = strLastName[0];



//    Console.WriteLine( string.Format("{0}{1}{2}{3}{4}{5}{6}{7}", char.ToUpper(first), char.ToUpper(second), thr[0], strFirstName.Length, strLastName.Length, SumDigits(dtDateofBirth.Month), SumDigits(dtDateofBirth.Day), SumDigits(dtDateofBirth.Year)));

//        }
//public static string SumDigits(int value)
//{
//    int sum = 0;
//    while (value != 0)
//    {
//        int digit = value % 10;
//        sum = sum + digit;
//        value = value / 10;
//    }
//    return sum.ToString();
//}