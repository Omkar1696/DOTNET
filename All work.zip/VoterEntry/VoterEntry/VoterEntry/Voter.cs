﻿using System;
using VoterEntry.Exceptions;

namespace VoterEntry
{
    public class Voter
    {
        // TODO: Write your code Here

        public string VoterID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public DateTime DateofBirth { get; set; }
        public int Age { get; set; }
        public string FathersName { get; set; }
        public string Gender { get; set; }
        public string Address { get; set; }
        public string ConstituencyName { get; set; }

        public Voter(string FirstName,string LastName,string FathersName,string Gender,string Address,string ConstituencyName, DateTime DOB )
        {
            this.FirstName = FirstName;
            this.LastName = LastName;
            this.Gender = Gender;
            DateofBirth = DOB;
            Age = DateTime.Now.Subtract(DateofBirth).Days/ 365;
            this.ConstituencyName = ConstituencyName;
            this.Address = Address;
            this.FathersName = FathersName;


        }
        public Voter()
        {

        }
    }
}


//{ get
//            {
//                return this.Age;
//            }
//set
//            {
//                if ((DateTime.Today).Year - DateofBIrth.Year > 18)
//                {
//                    IsAdult = true;
//                }
//            }
//        }