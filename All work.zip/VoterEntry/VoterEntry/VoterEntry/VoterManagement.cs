﻿using System;
using System.Collections.Generic;
using VoterEntry.Exceptions;
namespace VoterEntry
{
    
    public class VoterManagement
    {
        // TODO: Write your code here
        public List<Voter> VoterList;

        public VoterManagement()
        {
            VoterList = new List<Voter>();
        }

        public string AddVoter(Voter obj)
        {
             
            if (obj == null)
                return null;
            else
            {
                try {
                    // if ((!(string.IsNullOrEmpty(obj.FirstName)) && !(string.IsNullOrEmpty(obj.LastName)) && !(string.IsNullOrEmpty(obj.Gender)) && !(string.IsNullOrEmpty(obj.ConstituencyName)) && !(string.IsNullOrEmpty(obj.Address)) && obj.DateofBirth != null))
                    if (!(String.IsNullOrEmpty(obj.FirstName)))
                    {
                        Console.WriteLine(("adder"+obj.Age));
                        if (obj.Age >= 18)
                        {
                            VoterList.Add(obj);
                            return obj.VoterID;
                        }
                        else
                        {
                            throw new AgeException("Age shouldn't be less than 18");
                        }
                    }
                }
                catch(AgeException exp)
                {
                    throw exp;
                }
                catch(Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                return null;
            }
        }


        public bool ModifyVoter(Voter obj)
        {
            if (obj == null)
                return false;
            else
            { 
                
                if ((String.IsNullOrEmpty(obj.FirstName) || String.IsNullOrEmpty(obj.LastName) || String.IsNullOrEmpty(obj.Gender)|| String.IsNullOrEmpty(obj.ConstituencyName) || String.IsNullOrEmpty(obj.Address) || obj.DateofBirth == null))
                {
                    int inlist = 0;
                    foreach (var inst in VoterList)
                    {
                        if (inst == obj)
                            inlist = 1;
                    }
                     if (inlist == 1)
                    { 
                            Voter tempvoter = null;
                       try { 
                        if (obj.Age >= 18)
                            {
                                foreach (var inst in VoterList)
                                {
                                    if (inst.VoterID == obj.VoterID)
                                    {

                                        tempvoter = inst;
                                        break;
                                    }
                                }
                                tempvoter.FirstName = obj.FirstName;
                                tempvoter.FathersName = obj.FathersName;
                                tempvoter.Address = obj.Address;
                                tempvoter.ConstituencyName = obj.ConstituencyName;
                                tempvoter.LastName = obj.LastName;
                          }
                            else
                            {
                                throw new AgeException("Age shouldn't be less than 18");
                            }
                        
                }
                catch (AgeException exp)
                    {
                        throw exp;
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                    }
                    return false;
                    }
                    
                }
                return false;
            }
        }

        public Voter SearchVoter(string strVoterID)
        {
            foreach (var inst in VoterList)
            {
                if (inst.VoterID == strVoterID)
                {

                    return inst;
                }
            }
            return null;
        }

        public bool DeleteVoter(string strVoterID)
        {
            Voter tempvoter = null;
           
                foreach (var inst in VoterList)
                {
                    if (inst.VoterID == strVoterID)
                    {

                        tempvoter = inst;
                        break;
                    }
                }
            if (tempvoter != null) {
                VoterList.Remove(tempvoter);
                return true;
            }
            return false;
            
        }

        public List<Voter> GetVoterList()
        {
            return VoterList;
        }
    }
}
