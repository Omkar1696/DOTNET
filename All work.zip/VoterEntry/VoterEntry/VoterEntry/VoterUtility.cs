﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VoterEntry.Utility
{
    public class VoterUtility
    {
        public string GenerateVoterID(string strFirstName, string strLastName, DateTime dtDateofBirth)
        {
            char first = strFirstName[0];
            char second = strLastName[0];
            DayOfWeek third =  dtDateofBirth.DayOfWeek;
            string thr = third.ToString();

            return string.Format("{0}{1}{2}{3}{4}{5}{6}{7}",char.ToUpper(first),char.ToUpper(second),thr[0],strFirstName.Length,strLastName.Length, SumDigits(dtDateofBirth.Month), SumDigits(dtDateofBirth.Day), SumDigits(dtDateofBirth.Year));

        }
        public string SumDigits(int value)
        {
            int sum = 0;
            while (value != 0)
            {
                int digit = value % 10;
                sum = sum + digit;
                value = value / 10;
            }
            return sum.ToString();
        }
    }
}
