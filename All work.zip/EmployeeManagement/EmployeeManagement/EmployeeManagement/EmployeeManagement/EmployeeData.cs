﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeManagement
{
    public class EmployeeData
    {
        //TODO : Write your code here.
        List<Employee> EmployeeList = new List<Employee>();
        public EmployeeData()
        {
            // TODO: Write your code here.
        }
        public string AddEmployee(Employee obj)
        {
            if (obj != null)
            {
                new EmployeeManagement.Utility.EmployeeUtility().GenerateUserName(obj, 1);
                EmployeeList.Add(obj);
                return obj.UserID;
            }else
            {
                return null;
            }
        }

        public bool ModifyEmployee(Employee obj)
        {
            if (obj != null)
            {
                //modify
                return true;
            }
            else
            {
                return false;
            }
        }

        public Employee SearchEmployee(string strUserID)
        {
            if (!string.IsNullOrEmpty(strUserID))
            {
                foreach (var inst in EmployeeList)
                {
                    if (inst.UserID == strUserID)
                    {
                        return inst;
                    }
                }
            }
            return null;
        }

        public bool DeleteEmployee(string strUserID)
        {
            if (strUserID != null)
            {
                Employee found = null;
                foreach ( Employee inst in EmployeeList)
                {
                    if (inst.UserID == strUserID)
                    {
                        found = inst;
                        break;
                    }
                }
                EmployeeList.Remove(found);
            }
            return false;

        }


        public List<Employee> GetAllEmployees()
        {
            List<Employee> listInstance = new List<Employee>();

            foreach(var obj in EmployeeList)
            {
                listInstance.Add(obj);
            }
            return listInstance;
        }
    }
}
