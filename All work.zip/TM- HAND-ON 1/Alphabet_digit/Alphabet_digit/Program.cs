﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Alphabet_digit
{
    class Program
    {
        static void Main(string[] args)
        {
            //dynamic input;
            Console.WriteLine("Enter a character to check if it alphabet or digit\n--Enter only single character");
            char character = Convert.ToChar(Console.ReadLine());

            if (char.IsDigit(character))
            {
                Console.WriteLine("It's a Digit");
            }
            else if(char.IsLetter(character))
            {
                Console.Write("It's a Alphabet");
            }
            else
            {
                Console.WriteLine("Not a alphabet or Digit");
            }
            
            Console.ReadKey();
        }
    }
}
