﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Increment_Character
{
    class Program
    {
        static void Main(string[] args)
        {
            string input;
            //int letter =0, digit = 0, len =0;
            Console.WriteLine("Enter an Alphanumeric");

            input = (Console.ReadLine());

            foreach (int element in input)
            {
                //int number =  (element);
                Console.WriteLine((char)(element + 1));
                // Console.WriteLine((Char.IsLetter(input,  i)));


            }
        }
    }
}
