﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _3_sum_of_array
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the length of array");
            int len = Convert.ToInt32(Console.ReadLine());
            int[] arr = new int[len];
            Console.WriteLine("enter element inarray");
            for (int i = 0; i < len; i++)
            {
                arr[i] = Convert.ToInt32(Console.ReadLine());
            }
            int sum = 0;
            foreach (int ele in arr)
            {
                sum  =  sum+ ele;
            }

            Console.WriteLine("Sum of Array Elements is {0}", sum);
        }
    }
}
