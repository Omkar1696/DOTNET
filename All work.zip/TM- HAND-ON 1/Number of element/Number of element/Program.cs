﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Number_of_element
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the length of array");
            int len = Convert.ToInt32( Console.ReadLine());
            int[] arr = new int[len];
            Console.WriteLine("enter element inarray");
            for( int  i =0; i<len; i++)
            {
                arr[i] = Convert.ToInt32( Console.ReadLine());
            }
            int length_count = 0;
            //counting
            foreach(int ele in arr)
            {
                length_count = length_count + 1;
            }
            //count print
            Console.WriteLine("length of Array is {0}", length_count);
        }
    }
}
