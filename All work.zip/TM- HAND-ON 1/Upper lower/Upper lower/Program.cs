﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Upper_lower
{
    class Program
    {
        static void Main(string[] args)
        {

            string input;
            //int letter =0, digit = 0, len =0;
            Console.WriteLine("Enter an Alphanumeric");

            input = (Console.ReadLine());

            foreach (char element in input)
            {
                if (char.IsUpper(element))
                {
                    string ele = Convert.ToString(element);
                    Console.Write(ele.ToLower());

                }

                if (char.IsLower(element))
                {
                    string ele = Convert.ToString(element);
                    Console.Write(ele.ToUpper());
                   
                }
            }

        }
    }
}
