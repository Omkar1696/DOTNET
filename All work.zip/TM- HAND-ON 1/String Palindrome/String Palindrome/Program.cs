﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace String_Palindrome
{
    class Program
    {
        static void Main(string[] args)
        {
            string input, reverse;
            int flag = 0;
            //int letter =0, digit = 0, len =0;
            Console.WriteLine("Enter an string");
            input = (Console.ReadLine());

            reverse = ReverseString(input);
            
            for(int i = 0; i < input.Length; i++)
            {
                if (input[i] != reverse[i])
                {
                    flag = 1;
                    Console.WriteLine("NOt palindrome");
                    break;
                }
                
            }
            if (flag == 0) {
                Console.WriteLine("Palindrome!!!");
            }

        }

        public static string ReverseString(string s)
        {
            char[] arr = s.ToCharArray();
            Array.Reverse(arr);
            return new string(arr);
        }
    }
}
