﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2_reverse_array
{
    class Program
    {
        static void Main(string[] args)
        {

            int num = 7234534;
            int counter = 0;
            int numcp = 7234534;
            Console.WriteLine(num);
            while (num != 0)
            {
                int digit = num % 10;
                counter = counter + 1;
                num /= 10;
            }
            Console.WriteLine(counter);
            int[] arr = new int[counter];

            int i = 0;
            while (numcp != 0)
            {   
                int digit = numcp % 10;
                Console.WriteLine(digit);
                arr[i] = digit;
                Console.WriteLine(arr[i]);
                Console.WriteLine("entry{0}",i);
                numcp /= 10;
                i = i + 1;
            }
         
            foreach (int ele in arr)
            {
                Console.Write(ele);
            }

            Console.WriteLine("reverse\n");
            Array.Reverse(arr);
            foreach (int ele in arr)
            {
                Console.Write(ele);
            }


            //Console.WriteLine(arr);
            Console.ReadKey();
        }
    }
}
