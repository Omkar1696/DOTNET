﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DATATYPES
{
    class Program
    {
        static void Main(string[] args)
        {
            string input;
            //int letter =0, digit = 0, len =0;
            Console.WriteLine("Enter an String");

            input = (Console.ReadLine());
            Console.WriteLine("part1: REVERSE");
            Console.WriteLine(ReverseString(input));

            Console.WriteLine("\npart2: 2nd position to end proint\n");
            for(int i =2;i<input.Length;i++)
            {
                Console.Write(input[i]);
            }
            //Console.WriteLine(ReverseString(input));

            Console.WriteLine("\n\npart3: replace given index by $\n Insert index for the same");
            int index;
            index = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine(InsertDollar(input, index-1));

            Console.WriteLine("part4: Make a copy, manipulate oine print both");
            string str2 = String.Copy(input);
            Console.WriteLine(InsertDollar(str2,2));
            Console.WriteLine(input);

           // str2 = String.Copy(str1);
        }

        public static string ReverseString(string s)
        {
            char[] arr = s.ToCharArray();
            Array.Reverse(arr);
            return new string(arr);
        }
        public static string InsertDollar(string s, int index)
        {
            char[] arr = s.ToCharArray();
            arr[index] = '$';
            //Array.Reverse(arr);
            return new string(arr);
        }
    }

}
