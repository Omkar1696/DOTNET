﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication2
{
    class Squarearea
    {
        static void Main(string[] args)
        {
            int variable;
            Console.WriteLine("Enter the size of Square");
            variable = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("\nArea of Square is {0}", variable * variable);
           
        }
    }
}
