﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Place_in_number
{
    class Program
    {
        static void Main(string[] args)
        {
            //dynamic input;
            Console.WriteLine("Enter two numbers\n we will find number of occurance of second number in first");
            int num1 = Convert.ToInt32(Console.ReadLine());

            int num2 = Convert.ToInt32(Console.ReadLine());
            int counter = 0;


            for(int i = 1; num1 != 0; i++)
            {
                int digit = num1 % 10;
                if (digit == num2)
                {
                    counter = i;
                }
                num1 /= 10;
            }
            switch (counter)
            {
              
                case 1:
                    //statements 
                    Console.WriteLine("one's place");
                    break;
                case 2:
                    //statements 
                    Console.WriteLine("Ten's place");
                    break;
                case 3:
                    //statements 
                    Console.WriteLine("Hundredth place");
                    break;
                case 4:
                    //statements 
                    Console.WriteLine("Thousands place");
                    break;
                default:
                    Console.WriteLine("Not Found");
                    break;
            }

         
            Console.ReadKey();
        }
    }
}
