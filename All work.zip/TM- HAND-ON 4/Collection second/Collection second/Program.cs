﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Collection_second
{
    class Program
    {
        static void Main(string[] args)
        {
           

            //  MAking seversal emplyee object to be added
            Employee emp1 = new Employee("Harry", 1, 8576876);
            Employee emp2 = new Employee("Harmoine", 2, 87876);
            Employee emp3 = new Employee("Ron", 3, 87346);
            Employee emp4 = new Employee("Segret", 4, 83476);
            EmployeeDAL empData = new EmployeeDAL();

           
            //Adding all of them to list
            empData.AddEmployee(emp1,emp1.EmployeeID);
            empData.AddEmployee(emp2,emp2.EmployeeID);
            empData.AddEmployee(emp3,emp3.EmployeeID);
            empData.AddEmployee(emp4,emp4.EmployeeID);

            //deleting from any specific index
            Console.WriteLine(empData.DeleteEmployee(2));

            //Search using index
            Console.WriteLine( empData.SearchEmployee(1));

            //making an object array
            Employee[] arr = empData.GetAllEmployeeeListAll();
            foreach(var inst in arr)
            {
                Console.WriteLine(inst.EmployeeName+"\t" + inst.EmployeeID + "\t" + inst.Salary );
            }
            


        }
    }
}
