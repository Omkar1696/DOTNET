﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Collection_second
{
    class EmployeeDAL
    {
        SortedList obj = new SortedList();
        public bool AddEmployee(Employee e,int Empid)
        {
            obj.Add(Empid, e);
            return true;
        }


        public bool DeleteEmployee(int id)
        {
            bool Isfound = false;
            for (int i = 0; i < obj.Count; i++)
            {
                Employee employ = obj.GetByIndex(i) as Employee;
                if (employ.EmployeeID == id)
                {
                    Console.WriteLine(employ.EmployeeName + " withemployee id " + employ.EmployeeID + " removed");
                    obj.RemoveAt(i);
                    Isfound = true;
                    break;
                }

            }
            return Isfound;
        }

        public string SearchEmployee(int id)
        {
            if (obj.Count > id)
            {
                Employee temp1 = obj.GetByIndex(id) as Employee;
                return (temp1.EmployeeName);

            }
            return "Index out of bound ";
        }

        public Employee[] GetAllEmployeeeListAll()
        {
            Employee[] arr = new Employee[obj.Count];
            for (int i = 0; i < obj.Count; i++)
            {
                Employee inst = obj.GetByIndex(i) as Employee;
                arr[i] = inst;
            }
            return arr;
        }
    }
}
