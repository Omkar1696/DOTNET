﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Generic_collection_first
{
    class Employee
    {
        public string EmployeeName { set; get; }
        public int EmployeeID { set; get; }
        public double Salary { set; get; }

        public Employee(string Employeename, int empid, double salary)
        {
            EmployeeName = Employeename;
            EmployeeID = empid;
            Salary = salary;

        }
    }
}
