﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Generic_collection_first
{
    class EmployeeDAL
    {
        List<Employee> obj = new List<Employee>();
        public bool AddEmployee(Employee e)
        {
            obj.Add(e);
            return true;
        }

       
        public bool DeleteEmployee(int id)
        {
            bool Isfound = false;
            for(int i =0; i<obj.Count; i++)
            {
                Employee employ = obj[i] as Employee;
                if(employ.EmployeeID ==id)
                {
                    Console.WriteLine(employ.EmployeeName+ " withemployee id "+employ.EmployeeID+ " removed");
                    obj.Remove(employ);
                    Isfound = true;
                    break;
                }
               
            }
            return Isfound;
        }

        public string SearchEmployee(int id)
        {
            if (obj.Count > id)
            {
                Employee temp1 = obj[id] as Employee;
                return (temp1.EmployeeName);
                 
            }
                return "Index out of bound " ;
        }

        public Employee[] GetAllEmployeeeListAll()
        {
            return obj.ToArray();
                //ToArray(typeof(Employee)) as Employee[];

        }
    }
}

