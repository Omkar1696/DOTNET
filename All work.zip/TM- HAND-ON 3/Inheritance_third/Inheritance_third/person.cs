﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inheritance_third
{

    public interface IPayable
    {
        // interface members
        void CalculatePay();

    }
    class Person
    {
        public string FirstName;
        public string LastName;
        public string EmailAddress;
        public DateTime DateofBIrth;

        public readonly bool IsAdult;
        public readonly string SunSign;
        public readonly bool IsBirthDay;
        public string ScreenName;

        public Person(string FN, string LN, string EA, params int[] dates)
        {
            FirstName = FN;
            LastName = LN;
            EmailAddress = EA;
            DateofBIrth = new DateTime(dates[0], dates[1], dates[2]);

            #region Making_ScreenName
            Random random = new Random();
            int randval = random.Next(1, 3);
            int year = DateofBIrth.Year;
            int Last = Last = year % 100;

            switch (randval)
            {
                case 1:
                    ScreenName = string.Format("{0}{1}{2}{3}{4}", FirstName, LastName, DateofBIrth.Day, DateofBIrth.Month, Last);
                    break;
                case 2:
                    ScreenName = string.Format("{0}{1}{2}{3}", FirstName[0], LastName, DateofBIrth.Month, DateofBIrth.Day);
                    break;
            }


            //Console.WriteLine(ScreenName);
            #endregion

            #region SunSign

            switch (DateofBIrth.Month)
            {
                case 1:
                    if (DateofBIrth.Day <= 20)
                    { SunSign = " Capricorn"; }
                    else
                    { SunSign = " Aquarius"; }
                    break;
                case 2:
                    if (DateofBIrth.Day <= 19)
                    { SunSign = " Aquarius"; }
                    else
                    { SunSign = " Pisces"; }
                    break;
                case 3:
                    if (DateofBIrth.Day <= 20)
                    { SunSign = " Pisces"; }
                    else
                    { SunSign = " Aries"; }
                    break;
                case 4:
                    if (DateofBIrth.Day <= 20)
                    { SunSign = " Aries"; }
                    else
                    { SunSign = " Taurus"; }
                    break;
                case 5:
                    if (DateofBIrth.Day <= 21)
                    { SunSign = " Taurus"; }
                    else
                    { SunSign = " Gemini"; }
                    break;
                case 6:
                    if (DateofBIrth.Day <= 22)
                    { SunSign = " Gemini"; }
                    else
                    { SunSign = " Cancer"; }
                    break;
                case 7:
                    if (DateofBIrth.Day <= 22)
                    { SunSign = " Cancer"; }
                    else
                    { SunSign = " Leo"; }
                    break;
                case 8:
                    if (DateofBIrth.Day <= 23)
                    { SunSign = " Leo"; }
                    else
                    { SunSign = " Virgo"; }
                    break;
                case 9:
                    if (DateofBIrth.Day <= 23)
                    { SunSign = " Virgo"; }
                    else
                    { SunSign = " Libra"; }
                    break;
                case 10:
                    if (DateofBIrth.Day <= 23)
                    { SunSign = " Libra"; }
                    else
                    { SunSign = " Scorpio"; }
                    break;
                case 11:
                    if (DateofBIrth.Day <= 22)
                    { SunSign = " Scorpio"; }
                    else
                    { SunSign = " Sagittarius"; }
                    break;
                case 12:
                    if (DateofBIrth.Day <= 21)
                    { SunSign = " Sagittarius"; }
                    else
                    { SunSign = " Capricorn"; }
                    break;
                default:
                    Console.WriteLine("Your zodiac sign was not found! Please try again!");
                    break;
            }

            //Console.WriteLine(SunSign);
            #endregion

            #region bithday
            if ((DateTime.Compare(DateofBIrth.Date, DateTime.Today)) != -1)
            {
                IsBirthDay = true;
            }

            #endregion

            #region isAdult

            if ((DateTime.Today).Year - DateofBIrth.Year > 18)
            {
                IsAdult = true;
            }


            #endregion

        }


    }


    class HourlyEmployee : Person,IPayable
    {
        private double HoursWorked;
        private double PayPerHour;

        public HourlyEmployee(int PayPerHour, int HoursWorked, string FN, string LN, string EA, params int[] dates) : base(FN, LN, EA, dates)
        {
            this.HoursWorked = HoursWorked;
            this.PayPerHour = PayPerHour;
        }
        public void Display()
        {
            Console.WriteLine("\nEmployee details of {0}", FirstName);
            Console.WriteLine("EmployeeName : {0}", FirstName + " " + LastName);
            Console.WriteLine("Your Screen Name : {0}", ScreenName);
            Console.WriteLine("is birthday {0}", IsBirthDay);
            Console.WriteLine("is adult {0}", IsAdult);
            Console.WriteLine("Your Sunsign : {0} ", SunSign);
            Console.WriteLine("E-mail : {0}", EmailAddress);
            Console.WriteLine("Salary Details");

            Console.WriteLine("HoursWorked :  {0}hr", HoursWorked);
            Console.WriteLine("Pay per hour:  {0}hr", PayPerHour);


        }

        public void CalculatePay()
        {
            Console.WriteLine("Your pay {0}",HoursWorked * PayPerHour);
        }
    }

    class PermanantEmployee : Person, IPayable
    {

        private double HRA;
        private double DA;
        private double TotalPay;
        private double NetPay;
        private double Tax;

        public PermanantEmployee(int BasicSalary, string FN, string LN, string EA, params int[] dates) : base(FN, LN, EA, dates)
        {

            HRA = BasicSalary * .15;
            DA = BasicSalary * .10;
            TotalPay = BasicSalary + HRA + DA;
            Tax = TotalPay * .08;
            NetPay = TotalPay - Tax;
        }

        public void DetailDisplay()
        {
            Console.WriteLine("\nEmployee details of {0}", FirstName);
            Console.WriteLine("EmployeeName : {0}", FirstName + " " + LastName);
            Console.WriteLine("Your Screen Name : {0}", ScreenName);
            Console.WriteLine("is birthday {0}", IsBirthDay);
            Console.WriteLine("is adult {0}", IsAdult);
            Console.WriteLine("Your Sunsign : {0} ", SunSign);
            Console.WriteLine("E-mail : {0}", EmailAddress);
            Console.WriteLine("Salary Details");
            Console.WriteLine("HRA: {0}", HRA);
            Console.WriteLine("DA: {0}", DA);
            Console.WriteLine("GrossSalary: {0}", TotalPay);
            Console.WriteLine("NetSalary: {0}", NetPay);
            Console.WriteLine("TAX : {0}", Tax);
        }
        public void CalculatePay()
        {
            Tax = TotalPay * .08;
            NetPay = TotalPay - Tax;
        
            Console.WriteLine("Salary Details");
            Console.WriteLine("HRA: {0}", HRA);
            Console.WriteLine("DA: {0}", DA);
            Console.WriteLine("GrossSalary: {0}", TotalPay);
            Console.WriteLine("NetSalary: {0}", NetPay);
            Console.WriteLine("TAX : {0}", Tax);
        }
    }
}
