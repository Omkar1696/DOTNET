﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inheritance_second
{
    class Program
    {
        static void Main(string[] args)
        {

            HourlyEmployee ContractEmp = new HourlyEmployee(5,4,"Ronit","Roy","ronit.roy@company.com", 1885,08,15);
            ContractEmp.Display();


            

            PermanantEmployee RegularEmp = new PermanantEmployee(7500000, "Adam", "Sandler", "adam.sandler@holllywood.com", 1881, 06, 22);
            RegularEmp.DetailDisplay();
        }
    }
}
