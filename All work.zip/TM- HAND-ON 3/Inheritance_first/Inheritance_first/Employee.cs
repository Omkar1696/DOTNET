﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inheritance_first
{
    class Employee : Person

    {
        double Salary;

        public Employee(int salary, string FN, string LN, string EA, params int[] dates) : base(FN, LN, EA, dates)
        {
            this.Salary = salary;
        }
    }
}
