﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exception_Format
{
    
    class NegativeNumberException : Exception
    {
        public NegativeNumberException() : base()
        {

        }
        public NegativeNumberException(string message) : base(message)
        {

        }
        public NegativeNumberException(string message, Exception innerException)
            : base(message, innerException)
        {

        }
    }
    class EmptyInputException : Exception
    {
        public EmptyInputException() : base()
        {

        }
        public EmptyInputException(string message) : base(message)
        {

        }
        public EmptyInputException(string message, Exception innerException)
            : base(message, innerException)
        {

        }
    }

    class OtherthanAlphabetsException : Exception
    {
        public OtherthanAlphabetsException() : base()
        {

        }
        public OtherthanAlphabetsException(string message) : base(message)
        {

        }
        public OtherthanAlphabetsException(string message, Exception innerException)
            : base(message, innerException)
        {

        }
    }
}
