﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exception_Format
{
   
    class Program
    {
        static void Main(string[] args)
        {
            string[] subjects = { "Physics", "Chemistry", "Maths" };
            Dictionary<String, student> students = new Dictionary<string, student>();
            char continuevar;
            int A = 1;
            do
            {
                //Making student instance
                students[String.Format("student{0}", A)] = new student();
                //Student name input
                Console.WriteLine("Enter name of student");
                try
                {
                    students[String.Format("student{0}", A)].name = Console.ReadLine();
                }
                catch (Exception ex) { Console.WriteLine(ex.Message); }

                //subject marks entries
                Console.WriteLine("Enter subject then marks for 3 subject\n");
                foreach(var subject in subjects)
                {
                    Console.Write("\t"+subject+"marks: ");
                    
                    int mark = 0;
                    
                    try
                    {
                        mark = int.Parse(Console.ReadLine());
                        if (mark <= 0)
                        {
                            throw new NegativeNumberException("Marks can't be negative");
                        }
                    }
                    catch (NegativeNumberException ex1)
                    {
                        Console.WriteLine(ex1.Message);
                        Console.WriteLine(ex1.StackTrace);
                    }
                    catch (FormatException ex)
                    {
                        Console.WriteLine(ex.Message);
                        Console.WriteLine(ex.StackTrace);
                    }
                    students[String.Format("student{0}", A)].hashTable.Add(subject, mark);

                }
                A += 1;
                //iteration part
                Console.WriteLine("if you want to continue enter y else any other character");
                continuevar = char.Parse(Console.ReadLine());

            } while (continuevar == 'y' | continuevar == 'Y');
            
            //inputs Display
            Console.WriteLine("do you wanna have a look at data enteries press y");
            continuevar = char.Parse(Console.ReadLine());
            if(continuevar == 'y' | continuevar == 'Y')
            {
                Console.WriteLine("Subject\t P \t C\t M");
                int limit = A;
                for( A=1;A<limit;A++)
                {
                    Console.WriteLine(students[String.Format("student{0}", A)].name+"\t"+ students[String.Format("student{0}", A)].hashTable[subjects[0]] + "\t" + students[String.Format("student{0}", A)].hashTable[subjects[1]] + "\t" + students[String.Format("student{0}", A)].hashTable[subjects[2]]);
                }
            }
        }
    }
}
