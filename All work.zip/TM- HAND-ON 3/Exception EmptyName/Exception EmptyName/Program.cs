﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exception_EmptyName
{
    class Program
    {
        static void Main(string[] args)
        {

            char continuevar;
            int A = 1;
            do
            {
                //input dat of birth
                Console.WriteLine("Enter the date of birth of person as yyyy/mm/dd");

                string date = Console.ReadLine();
                string[] dates =  date.Split('/');

                try
                {
                    //object instance
                    Person human = new Person(int.Parse(dates[0]), int.Parse(dates[1]), int.Parse(dates[2]));
                    //object fields input
                    Console.WriteLine("Enter the name of person as firstname ");
                    human.FirstName = Console.ReadLine();

                    Console.WriteLine("Enter the name of person as lastname ");
                    human.LastName = Console.ReadLine();

                    Console.WriteLine("Enter your email id");
                    human.EmailAddress = Console.ReadLine();
                    Console.WriteLine();
                    Console.WriteLine();
                    human.DetailDisplay();
                }
                catch (OtherthanAlphabetsException ex1)
                {
                    Console.WriteLine(ex1.Message);
                }
                catch (EmptyInputException ex2)
                {
                    Console.WriteLine(ex2.Message);
                }
                catch(Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }

                A += 1;
                //iteration part
                Console.WriteLine("if you want to continue enter y");
                continuevar = char.Parse(Console.ReadLine());

            } while (continuevar == 'y' | continuevar == 'Y');


        }

    }

}

