﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Exception_EmptyName
{
    class Person
    {
        public string FirstName
        {
            set
            {
                if (string.IsNullOrEmpty(value))
                    throw new EmptyInputException("Empty input for Firstname");
                if (string.IsNullOrWhiteSpace(value))
                    throw new EmptyInputException("Empty or whitespace input is not valid");
                char[] letters = value.ToCharArray();
                foreach (char ch in letters)
                {
                    if (Char.IsLetter(ch))
                    {
                        throw new OtherthanAlphabetsException("Input must only contain Alphabets");
                    }
                }
            }
            get { return FirstName; }
        
        }
        public string LastName
        {
            set
            {
                if (string.IsNullOrEmpty(value))
                    throw new EmptyInputException("Empty input for Firstname");
                if (string.IsNullOrWhiteSpace(value))
                    throw new EmptyInputException("Empty or whitespace input is not valid");
                char[] letters = value.ToCharArray();
                foreach (char ch in letters)
                {
                    if (Char.IsLetter(ch))
                    {
                        throw new OtherthanAlphabetsException("Input must only contain Alphabets");
                    }
                }
            }
            get {return FirstName;}
        }
        public string EmailAddress;
        public DateTime DateofBIrth;

        public readonly bool IsAdult;
        public readonly string SunSign;
        public readonly bool IsBirthDay;
       

        public Person(params int[] dates)
        {
            
            DateofBIrth = new DateTime(dates[0], dates[1], dates[2]);

            
           

            #region SunSign

            switch (DateofBIrth.Month)
            {
                case 1:
                    if (DateofBIrth.Day <= 20)
                    { SunSign = " Capricorn"; }
                    else
                    { SunSign = " Aquarius"; }
                    break;
                case 2:
                    if (DateofBIrth.Day <= 19)
                    { SunSign = " Aquarius"; }
                    else
                    { SunSign = " Pisces"; }
                    break;
                case 3:
                    if (DateofBIrth.Day <= 20)
                    { SunSign = " Pisces"; }
                    else
                    { SunSign = " Aries"; }
                    break;
                case 4:
                    if (DateofBIrth.Day <= 20)
                    { SunSign = " Aries"; }
                    else
                    { SunSign = " Taurus"; }
                    break;
                case 5:
                    if (DateofBIrth.Day <= 21)
                    { SunSign = " Taurus"; }
                    else
                    { SunSign = " Gemini"; }
                    break;
                case 6:
                    if (DateofBIrth.Day <= 22)
                    { SunSign = " Gemini"; }
                    else
                    { SunSign = " Cancer"; }
                    break;
                case 7:
                    if (DateofBIrth.Day <= 22)
                    { SunSign = " Cancer"; }
                    else
                    { SunSign = " Leo"; }
                    break;
                case 8:
                    if (DateofBIrth.Day <= 23)
                    { SunSign = " Leo"; }
                    else
                    { SunSign = " Virgo"; }
                    break;
                case 9:
                    if (DateofBIrth.Day <= 23)
                    { SunSign = " Virgo"; }
                    else
                    { SunSign = " Libra"; }
                    break;
                case 10:
                    if (DateofBIrth.Day <= 23)
                    { SunSign = " Libra"; }
                    else
                    { SunSign = " Scorpio"; }
                    break;
                case 11:
                    if (DateofBIrth.Day <= 22)
                    { SunSign = " Scorpio"; }
                    else
                    { SunSign = " Sagittarius"; }
                    break;
                case 12:
                    if (DateofBIrth.Day <= 21)
                    { SunSign = " Sagittarius"; }
                    else
                    { SunSign = " Capricorn"; }
                    break;
                default:
                    Console.WriteLine("Your zodiac sign was not found! Please try again!");
                    break;
            }

            //Console.WriteLine(SunSign);
            #endregion

            #region bithday
            if ((DateTime.Compare(DateofBIrth.Date, DateTime.Today)) != -1)
            {
                IsBirthDay = true;
            }

            #endregion

            #region isAdult

            if ((DateTime.Today).Year - DateofBIrth.Year > 18)
            {
                IsAdult = true;
            }


            #endregion

        }

        public void DetailDisplay()
        {
            Console.WriteLine("\nEmployee details of {0}", FirstName);
            Console.WriteLine("EmployeeName : {0}", FirstName + " " + LastName);
            Console.WriteLine("is birthday {0}", IsBirthDay);
            Console.WriteLine("is adult {0}", IsAdult);
            Console.WriteLine("Your Sunsign : {0} ", SunSign);
            Console.WriteLine("E-mail : {0}", EmailAddress);

        }
    }

    
}
