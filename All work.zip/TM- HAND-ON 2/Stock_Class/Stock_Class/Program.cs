﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Stock_Class
{
    class Program
    {
        static void Main(string[] args)
        {
            Stock Newstock = new Stock("National stock","Country",120,20);
            Console.WriteLine(Newstock.GetChangePercentage());
        }
    }
}
