﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RandomHelper_class
{
    public class RandomHelper
    {
        public static int RandInt(int lower,int upper)
        {
            Random random = new Random();
            return random.Next(lower, upper);
            
        }

        public static double RandDouble(int lower,int max)
        {
            Random random = new Random();
            return random.Next(lower,max);
        
        }

    }
}
