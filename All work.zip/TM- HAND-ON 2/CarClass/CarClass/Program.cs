﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarClass
{
    class Program
    {
        static void Main(string[] args)
        {
            Car New = new Car("Audi","R8",2017,"1.2cr");
            New.DisplayCar();
        }
    }
}
