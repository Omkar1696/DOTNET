﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sort_substring
{
    class Program
    {
        static void Main(string[] args)
        {

            //dynamic input;
            Console.WriteLine( "Number of string you want to enter\n Insert format -> string initial_of_substring end_of_substring");
            int no_of_input = Convert.ToInt32(Console.ReadLine());
            string[,] values = new string[no_of_input,3];

            for(int  i=0;i<no_of_input;i++)
            {
                Console.WriteLine("enter word no.{0}",i+1);
                string temp  = (Console.ReadLine());

                //Console.WriteLine("Range 1 - {0}:",values[i,0].Length);
                string[] words = temp.Split(' ');
                values[i, 0] = words[0];
                values[i, 1] = words[1];
                values[i, 2] = words[2];
            }

           /* for (int i = 0; i < no_of_input; i++)
            {

                Console.WriteLine(values[i, 0]); 
                Console.WriteLine(values[i, 1]); 
                Console.WriteLine(values[i, 2]);  
            }
            */
            for (int i = 0; i < no_of_input; i++)
            {
                int init = Convert.ToInt32 (values[i, 1]) ;
                int end = Convert.ToInt32(values[i, 2]) ;
                //Console.WriteLine("inserting inputs");
                //Console.WriteLine(init);
                //Console.WriteLine(end);
                //Console.Write("\n OUTPUT of {0}  ",i +1);
                Sortsubstring(values[i, 0], init ,end);


            }
           
        }
        public static string Sortsubstring(string s,int indexinit, int indexend)
        {
            int diff = indexend - indexinit;
            char[] arr = s.ToCharArray();
            Array.Sort(arr, indexinit - 1 ,  diff+1);
            Array.Reverse(arr, indexinit - 1, diff + 1);
            Console.Write(arr);
            Console.WriteLine();
            return new string(arr);
        }
    }
}
