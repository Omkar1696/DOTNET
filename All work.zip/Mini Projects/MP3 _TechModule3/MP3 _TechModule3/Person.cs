﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MP3__TechModule3
{
    class Person
    {
        public string FirstName;
        public string LastName;
        public string EmailAddress;
        public DateTime DateofBIrth;

        public readonly bool IsAdult;
        public readonly string SunSign;
        public readonly bool IsBirthDay;
        public string ScreenName;

        public Person(string FN, string LN, string EA)
        {
            FirstName = FN;
            LastName = LN;
            EmailAddress = EA;
        }

        public Person(string FN, string LN, params int[] dates)
        {
            FirstName = FN;
            LastName = LN;
            DateofBIrth = new DateTime(dates[0], dates[1], dates[2]);
            #region Making_ScreenName
            Random random = new Random();
            int randval = random.Next(1, 3);
            int year = DateofBIrth.Year;
            int Last = Last = year % 100;

            switch (randval)
            {
                case 1:
                    ScreenName = string.Format("{0}{1}{2}{3}{4}", FirstName, LastName, DateofBIrth.Day, DateofBIrth.Month, Last);
                    break;
                case 2:
                    ScreenName = string.Format("{0}{1}{2}{3}", FirstName[0], LastName, DateofBIrth.Month, DateofBIrth.Day);
                    break;
            }


            //Console.WriteLine(ScreenName);
            #endregion

            #region SunSign

            switch (DateofBIrth.Month)
            {
                case 1:
                    if (DateofBIrth.Day <= 20)
                    { SunSign = " Capricorn"; }
                    else
                    { SunSign = " Aquarius"; }
                    break;
                case 2:
                    if (DateofBIrth.Day <= 19)
                    { SunSign = " Aquarius"; }
                    else
                    { SunSign = " Pisces"; }
                    break;
                case 3:
                    if (DateofBIrth.Day <= 20)
                    { SunSign = " Pisces"; }
                    else
                    { SunSign = " Aries"; }
                    break;
                case 4:
                    if (DateofBIrth.Day <= 20)
                    { SunSign = " Aries"; }
                    else
                    { SunSign = " Taurus"; }
                    break;
                case 5:
                    if (DateofBIrth.Day <= 21)
                    { SunSign = " Taurus"; }
                    else
                    { SunSign = " Gemini"; }
                    break;
                case 6:
                    if (DateofBIrth.Day <= 22)
                    { SunSign = " Gemini"; }
                    else
                    { SunSign = " Cancer"; }
                    break;
                case 7:
                    if (DateofBIrth.Day <= 22)
                    { SunSign = " Cancer"; }
                    else
                    { SunSign = " Leo"; }
                    break;
                case 8:
                    if (DateofBIrth.Day <= 23)
                    { SunSign = " Leo"; }
                    else
                    { SunSign = " Virgo"; }
                    break;
                case 9:
                    if (DateofBIrth.Day <= 23)
                    { SunSign = " Virgo"; }
                    else
                    { SunSign = " Libra"; }
                    break;
                case 10:
                    if (DateofBIrth.Day <= 23)
                    { SunSign = " Libra"; }
                    else
                    { SunSign = " Scorpio"; }
                    break;
                case 11:
                    if (DateofBIrth.Day <= 22)
                    { SunSign = " Scorpio"; }
                    else
                    { SunSign = " Sagittarius"; }
                    break;
                case 12:
                    if (DateofBIrth.Day <= 21)
                    { SunSign = " Sagittarius"; }
                    else
                    { SunSign = " Capricorn"; }
                    break;
                default:
                    Console.WriteLine("Your zodiac sign was not found! Please try again!");
                    break;
            }

            //Console.WriteLine(SunSign);
            #endregion

            #region bithday
            if ((DateTime.Compare(DateofBIrth.Date, DateTime.Today)) != -1)
            {
                IsBirthDay = true;
            }

            #endregion

            #region isAdult

            if ((DateTime.Today).Year - DateofBIrth.Year > 18)
            {
                IsAdult = true;
            }


            #endregion

        }

        public Person(string FN, string LN, string EA, params int[] dates)
        {
            FirstName = FN;
            LastName = LN;
            EmailAddress = EA;
            DateofBIrth = new DateTime(dates[0], dates[1], dates[2]);
          
            #region Making_ScreenName
            Random random = new Random();
            int randval = random.Next(1, 3);
            int year = DateofBIrth.Year;
            int Last = Last = year % 100;

            switch (randval)
            {
                case 1:
                    ScreenName = string.Format("{0}{1}{2}{3}{4}", FirstName, LastName, DateofBIrth.Day, DateofBIrth.Month, Last);
                    break;
                case 2:
                    ScreenName = string.Format("{0}{1}{2}{3}", FirstName[0], LastName, DateofBIrth.Month, DateofBIrth.Day);
                    break;
            }


            //Console.WriteLine(ScreenName);
            #endregion

            #region SunSign

            switch (DateofBIrth.Month)
            {
                case 1:
                    if (DateofBIrth.Day <= 20)
                    { SunSign = " Capricorn"; }
                    else
                    { SunSign = " Aquarius"; }
                    break;
                case 2:
                    if (DateofBIrth.Day <= 19)
                    { SunSign = " Aquarius"; }
                    else
                    { SunSign = " Pisces"; }
                    break;
                case 3:
                    if (DateofBIrth.Day <= 20)
                    { SunSign = " Pisces"; }
                    else
                    { SunSign = " Aries"; }
                    break;
                case 4:
                    if (DateofBIrth.Day <= 20)
                    { SunSign = " Aries"; }
                    else
                    { SunSign = " Taurus"; }
                    break;
                case 5:
                    if (DateofBIrth.Day <= 21)
                    { SunSign = " Taurus"; }
                    else
                    { SunSign = " Gemini"; }
                    break;
                case 6:
                    if (DateofBIrth.Day <= 22)
                    { SunSign = " Gemini"; }
                    else
                    { SunSign = " Cancer"; }
                    break;
                case 7:
                    if (DateofBIrth.Day <= 22)
                    { SunSign = " Cancer"; }
                    else
                    { SunSign = " Leo"; }
                    break;
                case 8:
                    if (DateofBIrth.Day <= 23)
                    { SunSign = " Leo"; }
                    else
                    { SunSign = " Virgo"; }
                    break;
                case 9:
                    if (DateofBIrth.Day <= 23)
                    { SunSign = " Virgo"; }
                    else
                    { SunSign = " Libra"; }
                    break;
                case 10:
                    if (DateofBIrth.Day <= 23)
                    { SunSign = " Libra"; }
                    else
                    { SunSign = " Scorpio"; }
                    break;
                case 11:
                    if (DateofBIrth.Day <= 22)
                    { SunSign = " Scorpio"; }
                    else
                    { SunSign = " Sagittarius"; }
                    break;
                case 12:
                    if (DateofBIrth.Day <= 21)
                    { SunSign = " Sagittarius"; }
                    else
                    { SunSign = " Capricorn"; }
                    break;
                default:
                    Console.WriteLine("Your zodiac sign was not found! Please try again!");
                    break;
            }

            //Console.WriteLine(SunSign);
            #endregion

            #region bithday
            if ((DateTime.Compare(DateofBIrth.Date, DateTime.Today)) != -1)
            {
                IsBirthDay = true;
            }

            #endregion

            #region isAdult

            if ((DateTime.Today).Year - DateofBIrth.Year > 18)
            {
                IsAdult = true;
            }


            #endregion

        }


    }
}
