﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MP2_InterestCalculator
{
    class FD_customer : AccountCommon
    {
        public int No_of_days { set; get; }
        public int Age { set; get; }
        public override double CalculateInterest()
        {

            if (No_of_days < 7)
            {
                Console.WriteLine("There is a minimum limit of seven days. Invalid days input");

            }
            if (No_of_days > 7 & No_of_days <= 14)
            {
                if (Amount < 10000000) { Interest_rate = Age < 60 ? 4.50 : 5.0; } else { Interest_rate = 6.50; }
            }
            if (No_of_days >= 14 & No_of_days <= 29)
            {
                if (Amount < 10000000) { Interest_rate = Age < 60 ? 4.75 : 5.25; } else { Interest_rate = 6.75; }
            }
            if (No_of_days >= 30 & No_of_days <= 45)
            {
                if (Amount < 10000000) { Interest_rate = Age < 60 ? 5.50 : 6.0; } else { Interest_rate = 6.75; }
            }
            if (No_of_days >= 45 & No_of_days <= 60)
            {
                if (Amount < 10000000) { Interest_rate = Age < 60 ? 7 : 7.50; } else { Interest_rate = 8; }
            }
            if (No_of_days >= 61 & No_of_days <= 184)
            {
                if (Amount < 10000000) { Interest_rate = Age < 60 ? 7.50 : 8.0; } else { Interest_rate = 8.50; }
            }
            if (No_of_days >= 185 & No_of_days < 365)
            {
                if (Amount < 10000000) { Interest_rate = Age < 60 ? 7.50 : 8.50; } else { Interest_rate = 10; }
            }
            if (No_of_days > 365)
            {
                if (Amount < 10000000) { Interest_rate = Age < 60 ? 7.50 : 8.50; } else { Interest_rate = 10; }
            }
            return (Amount * Interest_rate) / 100;

        }
    }

    class RD_customer : AccountCommon
    {
        public int month { get; set; }
        public int Age { set; get; }
        public override double CalculateInterest()
        {

            if (month < 6)
            {
                Console.WriteLine("There is a minimum limit of six month. Invalid month input");
            }
            if (month > 6)
            {
                { Interest_rate = Age < 60 ? 7.50 : 8.0; }
            }
            if (month >= 9)
            {
                { Interest_rate = Age < 60 ? 7.75 : 8.25; }
            }
            if (month >= 12)
            {
                { Interest_rate = Age < 60 ? 8 : 8.50; }
            }
            if (month >= 15)
            {
                { Interest_rate = Age < 60 ? 8.25 : 8.75; }
            }
            if (month >= 18)
            {
                { Interest_rate = Age < 60 ? 8.50 : 9.0; }
            }
            if (month >= 21)
            {
                { Interest_rate = Age < 60 ? 8.75 : 9.25; }
            }
            return (Amount * Interest_rate) / 100;
        }

    }
        class SB_customer : AccountCommon
    {
            public string Type { get; set; }
            public override double CalculateInterest()
                {
                if (Type == "N" |Type =="n" )
                    Interest_rate = 4;
                if (Type == "NR" | Type == "nr" | Type == "Nr" | Type == "nR")
                    Interest_rate = 6;

                return (Amount * Interest_rate) / 100; 
                }
        }

 }

