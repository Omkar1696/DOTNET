﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MP2_InterestCalculator
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("\nSelect the option:\n1.Interest Calculator –SB\n2.Interest Calculator –FD\n3.Interest Calculator –RD\n4.Exit");
            int input = int.Parse(Console.ReadLine());

            switch(input)
            {
                case 1:
                    SB_customer SB = new SB_customer();
                    Console.WriteLine("Enter the average Amount in your your Account:");
                    SB.Amount = double.Parse(Console.ReadLine());


                    Console.WriteLine("Type of account \"N\" for normal and \"NR\" for NRI ");
                    SB.Type = (Console.ReadLine());


                    Console.WriteLine("Interest gained is:" +SB.CalculateInterest());

                    break;

                case 2:
                    FD_customer FD = new FD_customer();
                    Console.WriteLine("Enter the average Amount in your your Account:");
                    FD.Amount = double.Parse(Console.ReadLine());

                    Console.WriteLine("Enter the number of Days:");
                    FD.No_of_days = int.Parse(Console.ReadLine());

                    Console.WriteLine("Enter the age");
                    FD.Age = int.Parse(Console.ReadLine());

                    Console.WriteLine("Interest gained is:" + FD.CalculateInterest());
                    break;

                case 3:
                    RD_customer RD = new RD_customer();
                    Console.WriteLine("Enter the average Amount in your your Account:");
                    RD.Amount = double.Parse(Console.ReadLine());

                    Console.WriteLine("Enter your Age:");
                    RD.Age = int.Parse(Console.ReadLine());

                    Console.WriteLine("Enter the number of month:");
                    RD.month = int.Parse(Console.ReadLine());

                    Console.WriteLine("Interest gained is:" + RD.CalculateInterest());

                    break;
                    

                case 4:
                    Console.WriteLine("Hope it been helpful.Thank you!!!");
                    break;

            }

        }
    }
}


