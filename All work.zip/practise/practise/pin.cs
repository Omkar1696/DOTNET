﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace practise
{
    class pin
    {

        static void Main(string[] args)
        {
            Console.WriteLine(   pinnum(190,267,853));
        }
        public static int pinnum(int input1, int input2, int input3)
        {

            int[] arr = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
            int[] num = { 0, 0, 0, 0 };
            int[] digits1 = { 0, 0, 0 };
            int[] digits2 = { 0, 0, 0 };
            int[] digits3 = { 0, 0, 0 };

            int number =input1;
            for(int  i = 2; i >= 0; i--)
            {
                Console.WriteLine(number);
                int inst = number % 10;
                arr[inst] = arr[inst] + 1;
                digits1[i] = inst;
                number = number / 10;
            }
            number = input2;
            for (int i = 2; i >= 0; i--)
            {
                Console.WriteLine(number);
                int inst = number % 10;
                arr[inst] = arr[inst] + 1;
                digits2[i] = inst;
                number = number / 10;
            }
            number = input3;
            for (int i = 2; i >= 0; i--)
            {
                Console.WriteLine(number);
                int inst = number % 10;
                arr[inst] = arr[inst] + 1;
                digits3[i] = inst;
                number = number / 10;
            }


            
              
                int least = Math.Min(digits1[2], digits2[2]);
                num[3] = Math.Min(least, digits3[2]);
                Console.WriteLine(num[3]);

                 least = Math.Min(digits1[1], digits2[1]);
                num[2] = Math.Min(least, digits3[1]);
                Console.WriteLine(num[2]);

                 least = Math.Min(digits1[0], digits2[0]);
                num[1] = Math.Min(least, digits3[0]);
                Console.WriteLine(num[1]);
            
               for(int j = 9; j > 0; j--)
            {
                if (arr[j] > 0)
                {
                    num[0] = j;
                    break;
                }
                //Console.WriteLine(j+"----"+arr[j]);
            }
              
                return num[0] *1000 +num[1]*100 +num[2] *10+ num[3];
            }
        }

    }


