﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace practise
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(digitSum(123456));
        }
        public static int digitSum(int input1)
        {
            int num = input1;
            int sum = 0;
            int digisum = 0;
            Console.WriteLine(input1);

            while (num != 0)
            {
                while (num != 0)
                {
                    int digit = num % 10;

                    sum = sum + digit;
                    Console.WriteLine(sum);
                    num = num / 10;
                    Console.WriteLine("num =" +num);
                    Console.WriteLine("sum   =" + sum);
                }
                Console.WriteLine("out of first loop");
                int checkdigi = sum;
                digisum = 0;
                while (checkdigi != 0)
                {
                    checkdigi= checkdigi / 10;
                    digisum = digisum + 1;
                    Console.WriteLine("checkdigi"+ checkdigi);
                    Console.ReadKey();
                }
                Console.WriteLine("digisum" + digisum);
                if (digisum != 1)
                {
                    num = sum;
                    sum = 0;
                    
                }
            }

            return sum;
        }
    }
}
