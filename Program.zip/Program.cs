﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace stringmettl1
{
    class Program
    {
       using System;
using System.Collections.Generic;

//Read only region start
public class UserMainCode
    {
        public int findStringCode(string input1)
        {
            //Read only region end
            //Write code here
            int sum = 0;
            string summer = "";

            string[] str1 = input1.Split(' ');
            foreach (var wrd in str1)
            {
                int len = wrd.Length;
                Console.WriteLine("len" + len);
                string word = wrd.ToUpper();
                if (len % 2 != 0)
                {
                    sum = sum + (int)word[len / 2] - 64;
                    Console.WriteLine("oddsum" + sum);
                }
                for (int i = 0; i < len / 2; i++)
                {
                    Console.WriteLine("loop" + i);
                    Console.WriteLine("sum " + sum);
                    sum = sum + Math.Abs(((int)word[i] - 64) - ((int)word[len - 1 - i] - 64));
                    Console.WriteLine("Firstset" + sum);
                }

                summer = summer + sum.ToString();
                Console.WriteLine("summer" + summer);
                sum = 0;
            }
            return int.Parse(summer);

        }
    }
}
}
