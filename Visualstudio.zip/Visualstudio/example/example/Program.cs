﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace example
{
    class Program
    { 
       public int Sum = 0;
        public int Product = 0;
    
        static void Main(string[] args)
        {
            
            Program P = new Program();
            P.calculate(10, 20);
            Console.WriteLine("Sum is {0}\nProduct is {1}",P.Sum, P.Product);
        }

        public void calculate(int FN,int LN)
        {
            Sum = FN + LN;
            Product = FN * LN;
        }
    }
}
