﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClsRndmNum
{
    class RandomHelper
    {
        public static int Randint(int n1, int n2)
        {
            int max = Math.Max(n1, n2);
            int min = Math.Min(n1, n2);
            Random rand = new Random();
            return rand.Next(min, max);
        }
        public static double Randdouble(double n1,double n2)

        {
            double max = Math.Max(n1, n2);
            double min = Math.Min(n1, n2);
            Random rndm = new Random();
            return rndm.NextDouble() * (max - min) + min;
        }
    }
}
