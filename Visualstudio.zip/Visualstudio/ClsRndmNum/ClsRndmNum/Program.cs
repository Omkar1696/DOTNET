﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClsRndmNum
{
    class Program
    {
        static void Main(string[] args)
        {
            int rint = RandomHelper.Randint(100, 10);
            double rdouble = RandomHelper.Randdouble(2.5, 1.5);
            Console.WriteLine("Random Integer is {0}",rint);
            Console.WriteLine("Random Double is {0}",rdouble);

        }
    }
}
