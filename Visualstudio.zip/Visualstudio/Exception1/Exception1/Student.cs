﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exception1
{
    class Student
    {
        string Name;
        int Sub1;
        int Sub2;
        int Sub3;
        public Student(string Nm, int Subject1,int Subject2,int Subject3)
        {
            Name = Nm;
            Sub1 = Subject1;
            Sub2 = Subject2;
            Sub3 = Subject3;
        }
        public void StudentInfo()
        {
            Console.WriteLine("Name of Studen:",Name);
            Console.WriteLine("Subject1 marks: {0}",Sub1);
            Console.WriteLine("Subject2 marks: {0}",Sub2);
            Console.WriteLine("Subject3 marks: {0}",Sub3);
        }
    }
}
