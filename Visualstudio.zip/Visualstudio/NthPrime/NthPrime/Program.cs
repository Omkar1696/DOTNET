﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NthPrime
{
    class Program
    {
        static void Main(string[] args)
        {
            int N;
            int i=1;
            int j;
            int count = 0;
            int flag = 1;
            Console.WriteLine("Enter input");
            N = Convert.ToInt32(Console.ReadLine());

            for(flag <= N)
            {
                i++;
                for(j=1;j<=Math.Sqrt(i);j++)
                {
                    if(i%j==0)
                    {
                        count = count + 1;
                    }
                }
                if(count==1)
                {
                    flag = flag + 1;

                }
                count = 0;
            }
            Console.WriteLine("{0}th Prime number is {1}", N, i);
        }
    }
}
