﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceEmployee
{
    class Employee : person
    {
        double Salary;
       
        public Employee(double Salary, string FName, string LName, string Mail, DateTime DOB) : base(FName, LName, Mail, DOB)
        {
            this.Salary = Salary;
            Console.WriteLine("Salary:{0}", Salary);
        }
      
    }
}
