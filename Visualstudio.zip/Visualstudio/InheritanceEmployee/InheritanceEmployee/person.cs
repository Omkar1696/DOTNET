﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceEmployee
{
    class person
    {
        private string FirstName;
        private string LastName;
        private string EmailAddress;
        private DateTime DateofBirth;

        bool IsAdult;
        bool IsBirthDay;
        string ScreenName; 
        //SunSign not derived

        public person(string FName, string LName, string Mail, DateTime DOB)
        {
            FirstName = FName;
            LastName = LName;
            EmailAddress = Mail;
            DateofBirth = DOB;
            int year = DateofBirth.Year;
            int Last = Last = year % 100;

            ScreenName = string.Format("{0}{1}{2}{3}{4}", FirstName, LastName, DateofBirth.Day, DateofBirth.Month, Last);
            Console.WriteLine(ScreenName);
            if (DateTime.Equals(DateofBirth.Date, DateTime.Today))
            {
                IsBirthDay = true;
            }
            else
            {
                IsBirthDay = false;
            }
            Console.WriteLine("Is Birthday:{0}", IsBirthDay);

            if ((DateofBirth.Year - DateTime.Today.Year) <= 18)
            {
                IsAdult = true;
            }
            else
            {
                IsAdult = false;
            }
            Console.WriteLine("Is Adult:{0}", IsAdult);
        }

    }
}
