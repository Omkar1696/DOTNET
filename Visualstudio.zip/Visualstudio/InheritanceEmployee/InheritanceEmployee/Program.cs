﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceEmployee
{
    interface IPayable
    {
        void CalculatePay();
    }

    class Program
    {
       
        static void Main(string[] args)
        {
            PermanentEmployee P = new PermanentEmployee(100000, "John", "Richards", "johnrichards@ric.com", new DateTime(2017, 11, 12));
            P.DisplayStructure();
            P.CalculatePay();
            HourlyEmployee H = new HourlyEmployee(12, 100, "Anthony", "Martin", "anthonymartin@am.com", new DateTime(1987, 09, 11));
            H.Display();
            H.CalculatePay();
        }
    }
}
