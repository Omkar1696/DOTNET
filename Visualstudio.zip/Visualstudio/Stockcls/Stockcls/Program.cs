﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Stockcls
{
    class Program
    {
        static void Main(string[] args)
        {
            Stock Stck = new Stock("Ferrari", "Horse", 120, 20);
            double per_change = Stck.GetChangePercentage();
            Console.WriteLine("Percentage Change={0}", per_change);
        }
    }
}
