﻿using System;


namespace evenoddzero
{
    class Program
    {
        static void Main(string[] args)
        {
            int even = 0;
            int odd = 0;
            int zero = 0;
            int[] number = new int[5];
            for (int i = 0; i < 5; i++)
            {
                number[i] = Convert.ToInt32(Console.ReadLine());
            }
            for (int i = 0; i < 5; i++)
            {
                if (  number[i] == 0)
                {
                    
                    zero = zero + 1;

                }
                else if (number[i] % 2 != 0)
                {
                    odd = odd + 1;

                }
                else
                {
                    even = even + 1;
                }
            }
            Console.WriteLine("even {0}", even);

            Console.WriteLine("odd {0}", odd);
            Console.WriteLine("zero {0}", zero);
        }
    }
}
