﻿using System;

namespace digtsnalphbts
{
    class Program
    {
        static void Main(string[] args)
        {
            int i=1, j=1;
            do
            {
                if (i <= 10)
                {
                    if (j <= i)
                    {
                        Console.WriteLine(j);
                        j++;
                    }
                    
                    i++;
                  
                }

            }
            while (i <= 10);


        }
    }
}
