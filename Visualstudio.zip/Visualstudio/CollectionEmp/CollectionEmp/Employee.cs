﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CollectionEmp
{
    class Employee
    {
        public string EmployeeName { set; get; }
        public int EmployeeID { set; get; }
        public double Salary { set; get; }

        public Employee(string EmployeeName, int EmployeeID, double Salary)
        {
            this.EmployeeName = EmployeeName;
            this.EmployeeID = EmployeeID;
            this.Salary = Salary;
        }
        //public void EmpDetails()
        //{
        //    Console.WriteLine("EmployeeName:",EmployeeName);
        //    Console.WriteLine("EmployeeID:", EmployeeID);
        //    Console.WriteLine("Salary:", Salary);
        //}
    }
}
