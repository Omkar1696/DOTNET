﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace clscarmanfctr
{
    class Program
    {
       
        static void Main(string[] args)
        {
            Car Cr = new Car("MarutiSuzuki","Swift",2008,500000);
            Cr.DisplayCar();


        }
    }
}
