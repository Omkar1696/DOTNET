﻿using System;


namespace NumSwap
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 10, b = 20, c = 30, x;
            Console.Write("a={0},",a);
            Console.Write("b={0}",b);
            Console.Write("c={0}",c);
            x = c;
            c = b;
            b = a;
            a = x;
            Console.WriteLine();

            Console.Write("a={0},", a);
            Console.Write("b={0}", b);
            Console.Write("c={0}", c);
            Console.WriteLine();

        }
    }
}
