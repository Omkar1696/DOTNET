﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace ADOdemo
{
    public class EmployeeDAL
    {
        public List<Employee> ViewAllEmployees()
        {
            List<Employee> emplist = new List<Employee>();
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Server=.;Initial Catalog=DemoDB;User Id=sa;Password=wipro@123";
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "Select * from Employee";
            cmd.Connection = con;
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            if(dr.HasRows)
            {
                while(dr.Read())
                {
                    Employee emp = new Employee();
                    emp.Empid = int.Parse(dr["Empid"].ToString());
                    emp.Age = int.Parse(dr["Age"].ToString());
                    emp.EmpName = dr["EmpName"].ToString();
                    emp.Address = dr["Address"].ToString();
                    emp.Did = int.Parse(dr["Did"].ToString());
                    emplist.Add(emp);
                }
            }
            con.Close();
            return emplist;
        }

        public int AddEmployee(Employee emp)
        {
           
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Server=.;Initial Catalog=DemoDB;User Id=sa;Password=wipro@123";
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "Insert into Employee(EmpName,Age,[address],Did) values (@en,@Age,@add,@Did);select scope_identity()";
            cmd.Parameters.AddWithValue("@en", emp.EmpName);
            cmd.Parameters.AddWithValue("@Age", emp.Age);
            cmd.Parameters.AddWithValue("@add", emp.Address);
            cmd.Parameters.AddWithValue("@Did", emp.Did);
            cmd.Connection = con;
            con.Open();
            int Empid = int.Parse(cmd.ExecuteScalar().ToString());
            con.Close();
            return Empid;
        }
        public bool UpdateEmployee(Employee emp)
        {
           
            bool IsUpdated = false;
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Server=.;Initial Catalog=DemoDB;User Id=sa;Password=wipro@123";
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "Update Employee Set EmpName=@en,Age=@Age,address=@add,Did=@Did where EmpID=@Eid";
            cmd.Parameters.AddWithValue("@en", emp.EmpName);
            cmd.Parameters.AddWithValue("@Age", emp.Age);
            cmd.Parameters.AddWithValue("@add", emp.Address);
            cmd.Parameters.AddWithValue("@Did", emp.Did);
            cmd.Parameters.AddWithValue("@Eid", emp.Empid);
            cmd.Connection = con;
            con.Open();
            int rowCount = cmd.ExecuteNonQuery();
            con.Close();
            if (rowCount == 1)
            {
                IsUpdated=true;
            }
            return IsUpdated;
        }

        public bool DeleteEmployee(int empid)
        {
            bool IsDeleted = false;
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Server=.;Initial Catalog=DemoDB;User Id=sa;Password=wipro@123";
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "Delete from Employee where EmpID=@Eid";
            cmd.Parameters.AddWithValue("@Eid", empid);
            cmd.Connection = con;
            con.Open();
            int rowCount = cmd.ExecuteNonQuery();
            con.Close();
            if (rowCount == 1)
            {
                IsDeleted = true;
            }
            return IsDeleted;
        }

        public Employee SearchEmployee(int empid)
        {
            Employee emp = new Employee();
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Server=.;Initial Catalog=DemoDB;User Id=sa;Password=wipro@123";
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "select * from Employee where EmpID=@Eid";
            cmd.Parameters.AddWithValue("@Eid", empid);
            cmd.Connection = con;
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                dr.Read();
                emp.EmpName = dr["EmpName"].ToString();
                emp.Age = int.Parse(dr["Age"].ToString());
                emp.Address = dr["address"].ToString();
                emp.Did = int.Parse(dr["Did"].ToString());
            }
            
            else
            {
                Console.WriteLine("Record not found...");
            }
            con.Close();
            return emp;
        }


    }
}