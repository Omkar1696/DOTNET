﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ADOdemo
{
    public class Employee
    {
        public string EmpName { get; set; }
        public int Age { get; set; }
        public string Address { get; set; }
        public int Did { get; set; }

        public int Empid { get; set; }
    }
}