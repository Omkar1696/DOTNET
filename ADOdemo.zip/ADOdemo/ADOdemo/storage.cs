﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ADOdemo
{
    public class storage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Server=.;Initial Catalog=DemoDB;User Id=sa;Password=wipro@123";
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "Select * from Employee";
            cmd.Connection = con;
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            GridView1.DataSource = dr;
            GridView1.DataBind();
            con.Close();
        }

        protected void btnInsert_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Server=.;Initial Catalog=DemoDB;User Id=sa;Password=wipro@123";
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "Insert into Employee(EmpName,Age,[address],Did) values (@en,@Age,@add,@Did)";
            cmd.Parameters.AddWithValue("@en", tbEName.Text);
            cmd.Parameters.AddWithValue("@Age", tbAge.Text);
            cmd.Parameters.AddWithValue("@add", tbAdd.Text);
            cmd.Parameters.AddWithValue("@Did", tbDid.Text);
            cmd.Connection = con;
            con.Open();
            int rowCount = cmd.ExecuteNonQuery();
            con.Close();
            if (rowCount == 1)
            {
                Response.Write("Record Inserted..");
            }
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Server=.;Initial Catalog=DemoDB;User Id=sa;Password=wipro@123";
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "Update Employee Set EmpName=@en,Age=@Age,address=@add,Did=@Did where EmpID=@Eid";
            cmd.Parameters.AddWithValue("@en", tbEName.Text);
            cmd.Parameters.AddWithValue("@Age", tbAge.Text);
            cmd.Parameters.AddWithValue("@add", tbAdd.Text);
            cmd.Parameters.AddWithValue("@Did", tbDid.Text);
            cmd.Parameters.AddWithValue("@Eid", tbEid.Text);
            cmd.Connection = con;
            con.Open();
            int rowCount = cmd.ExecuteNonQuery();
            con.Close();
            if (rowCount == 1)
            {
                Response.Write("Record Updated..");
            }
        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Server=.;Initial Catalog=DemoDB;User Id=sa;Password=wipro@123";
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "Delete from Employee where EmpID=@Eid";
            cmd.Parameters.AddWithValue("@Eid", tbEid.Text);
            cmd.Connection = con;
            con.Open();
            int rowCount = cmd.ExecuteNonQuery();
            con.Close();
            if (rowCount == 1)
            {
                Response.Write("Record Deleted..");
            }
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Server=.;Initial Catalog=DemoDB;User Id=sa;Password=wipro@123";
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "select * from Employee where EmpID=@Eid";
            cmd.Parameters.AddWithValue("@Eid", tbEid.Text);
            cmd.Connection = con;
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                dr.Read();
                tbEName.Text = dr["EmpName"].ToString();
                tbAge.Text = dr["Age"].ToString();
                tbAdd.Text = dr["address"].ToString();
                tbDid.Text = dr["Did"].ToString();
            }
            else
            {
                Response.Write("Record not found...");
            }
            con.Close();
        }

    }
}